/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Objects;

/**
 * Clase que representa a un usuario de la biblioteca.
 * Almacena RUT, nombre completo, teléfono y correo electrónico.
 */
public class Usuario implements Comparable<Usuario> {
    private String rut;
    private String nombreCompleto;
    private String telefono;
    private String correo;

    public Usuario(String rut, String nombreCompleto, String telefono, String correo) {
        this.rut = rut;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getRut() { return rut; }
    public String getNombreCompleto() { return nombreCompleto; }
    public String getTelefono() { return telefono; }
    public String getCorreo() { return correo; }

    @Override
    public String toString() {
        return rut + " - " + nombreCompleto + " - " + telefono + " - " + correo;
    }

    // Para HashSet y HashMap: considera iguales los usuarios con mismo RUT
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        Usuario usuario = (Usuario) o;
        return rut.equalsIgnoreCase(usuario.rut);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rut.toLowerCase());
    }

    // Para TreeSet: ordena por nombre completo y, si hay empate, por RUT
    @Override
    public int compareTo(Usuario otro) {
        int comp = this.nombreCompleto.compareToIgnoreCase(otro.nombreCompleto);
        if (comp == 0) {
            comp = this.rut.compareToIgnoreCase(otro.rut);
        }
        return comp;
    }
}