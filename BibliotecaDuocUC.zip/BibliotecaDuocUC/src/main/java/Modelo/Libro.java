/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class Libro implements Comparable<Libro> {
    private static int contador = 1;
    private int id;
    private String titulo;
    private String autor;
    private boolean prestado;
    private Usuario usuarioPrestamo; // NUEVO: Usuario que tiene el libro prestado

    public Libro(String titulo, String autor) {
        this.id = contador++;
        this.titulo = titulo;
        this.autor = autor;
        this.prestado = false;
        this.usuarioPrestamo = null;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public boolean isPrestado() { return prestado; }
    public Usuario getUsuarioPrestamo() { return usuarioPrestamo; }

    public void prestarA(Usuario usuario) {
        this.prestado = true;
        this.usuarioPrestamo = usuario;
    }

    public void devolver() {
        this.prestado = false;
        this.usuarioPrestamo = null;
    }

    @Override
    public String toString() {
        String infoPrestamo = prestado ? " (Prestado a: " + usuarioPrestamo.getNombreCompleto() + ")" : "";
        return "[" + id + "] " + titulo + " - " + autor + (prestado ? " [Prestado]" : "") + infoPrestamo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Libro)) return false;
        Libro libro = (Libro) o;
        return titulo.equalsIgnoreCase(libro.titulo) && autor.equalsIgnoreCase(libro.autor);
    }

    @Override
    public int hashCode() {
        return titulo.toLowerCase().hashCode() + autor.toLowerCase().hashCode();
    }

    @Override
    public int compareTo(Libro otro) {
        int comp = this.titulo.compareToIgnoreCase(otro.titulo);
        if (comp == 0) {
            comp = this.autor.compareToIgnoreCase(otro.autor);
        }
        return comp;
    }
}