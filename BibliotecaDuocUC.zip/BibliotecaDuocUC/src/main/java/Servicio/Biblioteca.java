/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicio;

import Excepcion.LibroYaPrestadoException;
import Excepcion.LibroNoEncontradoException;
import Modelo.Usuario;
import Modelo.Libro;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.List;
import java.util.Comparator;

/**
 * Clase que representa la Biblioteca.
 * Contiene la lista de libros y el registro de usuarios.
 * Permite agregar, buscar y prestar libros, así como registrar y devolver.
 * Además, permite guardar y cargar libros desde archivos CSV.
 *
 * Usa ArrayList para la lista de libros, HashMap para usuarios,
 * HashSet para libros y usuarios únicos, y TreeSet para catálogos ordenados.
 *
 * @author Francisco Torres Palacios - Cristian Olivares Sandia
 */
public class Biblioteca {
    // Lista de libros disponibles en la biblioteca (orden de ingreso)
    private ArrayList<Libro> libros;
    // Mapa de usuarios registrados, clave: RUT
    private HashMap<String, Usuario> usuarios;

    // Conjunto único de libros (sin duplicados, sin orden)
    private HashSet<Libro> librosUnicos;
    // Conjunto único de usuarios (sin duplicados, sin orden)
    private HashSet<Usuario> usuariosUnicos;
    // Catálogo ordenado de libros (por título y autor)
    private TreeSet<Libro> catalogoOrdenado;
    // Usuarios ordenados por nombre completo y RUT
    private TreeSet<Usuario> usuariosOrdenados;

    /** Constructor: Inicializa las colecciones de libros y usuarios. */
    public Biblioteca() {
        libros = new ArrayList<>();
        usuarios = new HashMap<>();
        librosUnicos = new HashSet<>();
        usuariosUnicos = new HashSet<>();
        catalogoOrdenado = new TreeSet<>(Comparator.comparing(Libro::getTitulo, String.CASE_INSENSITIVE_ORDER)
                                                   .thenComparing(Libro::getAutor, String.CASE_INSENSITIVE_ORDER));
        usuariosOrdenados = new TreeSet<>(Comparator.comparing(Usuario::getNombreCompleto, String.CASE_INSENSITIVE_ORDER)
                                                    .thenComparing(Usuario::getRut, String.CASE_INSENSITIVE_ORDER));
    }

    /** Agrega un libro a la biblioteca y a todas las colecciones relacionadas. */
    public void agregarLibro(Libro libro) {
        libros.add(libro);
        librosUnicos.add(libro);
        catalogoOrdenado.add(libro);
    }

    /** Registra un usuario en la biblioteca y en todas las colecciones relacionadas. */
    public void agregarUsuario(Usuario usuario) {
        usuarios.put(usuario.getRut(), usuario);
        usuariosUnicos.add(usuario);
        usuariosOrdenados.add(usuario);
    }

    /** Devuelve el mapa de usuarios registrados. */
    public HashMap<String, Usuario> getUsuarios() {
        return usuarios;
    }

    /** Devuelve la lista de libros (orden de ingreso). */
    public List<Libro> getLibros() {
        return libros;
    }

    /** Devuelve el conjunto de libros únicos (HashSet). */
    public HashSet<Libro> getLibrosUnicos() {
        return librosUnicos;
    }

    /** Devuelve el catálogo ordenado de libros (TreeSet). */
    public TreeSet<Libro> getCatalogoOrdenado() {
        return catalogoOrdenado;
    }

    /** Devuelve el conjunto de usuarios únicos (HashSet). */
    public HashSet<Usuario> getUsuariosUnicos() {
        return usuariosUnicos;
    }

    /** Devuelve el conjunto de usuarios ordenados (TreeSet). */
    public TreeSet<Usuario> getUsuariosOrdenados() {
        return usuariosOrdenados;
    }

    /** Muestra todos los libros del catálogo en consola (ArrayList). */
    public void mostrarLibros() {
        if (libros.isEmpty()) {
            System.out.println("No hay libros en la biblioteca.");
        } else {
            System.out.println("Catálogo de libros:");
            for (Libro libro : libros) {
                System.out.println(libro);
            }
        }
    }

    /** Muestra el catálogo ordenado de libros (TreeSet). */
    public void mostrarCatalogoOrdenado() {
        if (catalogoOrdenado.isEmpty()) {
            System.out.println("No hay libros en el catálogo ordenado.");
        } else {
            System.out.println("Catálogo ordenado de libros:");
            for (Libro libro : catalogoOrdenado) {
                System.out.println(libro);
            }
        }
    }

    /** Busca libros cuyo título o autor contenga el texto dado (no distingue mayúsculas/minúsculas). */
    public List<Libro> buscarLibros(String texto) {
        List<Libro> encontrados = new ArrayList<>();
        String textoLower = texto.toLowerCase();
        for (Libro libro : libros) {
            if (libro.getTitulo().toLowerCase().contains(textoLower) ||
                libro.getAutor().toLowerCase().contains(textoLower)) {
                encontrados.add(libro);
            }
        }
        return encontrados;
    }

    /** Busca un libro por ID. Lanza excepción si no se encuentra. */
    public Libro buscarLibroPorId(int id) throws LibroNoEncontradoException {
        for (Libro libro : libros) {
            if (libro.getId() == id) {
                return libro;
            }
        }
        throw new LibroNoEncontradoException("No existe un libro con ese ID.");
    }

    /** Busca un libro exacto por título (ignorando mayúsculas/minúsculas). */
    public Libro buscarLibro(String titulo) throws LibroNoEncontradoException {
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                return libro;
            }
        }
        throw new LibroNoEncontradoException("El libro no existe en la biblioteca.");
    }

    /** Presta un libro por su ID, registrando el usuario que lo recibe. */
    public void prestarLibroPorId(int id, String rutUsuario) throws LibroNoEncontradoException, LibroYaPrestadoException {
        Libro libro = buscarLibroPorId(id);
        if (libro.isPrestado())
            throw new LibroYaPrestadoException("El libro ya está prestado.");
        Usuario usuario = usuarios.get(rutUsuario);
        if (usuario == null)
            throw new LibroNoEncontradoException("Usuario no encontrado.");
        libro.prestarA(usuario);
        System.out.println("Libro reservado exitosamente.");
    }

    /** Devuelve un libro por su ID. */
    public void devolverLibroPorId(int id) throws LibroNoEncontradoException {
        Libro libro = buscarLibroPorId(id);
        if (!libro.isPrestado()) {
            System.out.println("El libro no está prestado.");
        } else {
            libro.devolver();
            System.out.println("Libro devuelto exitosamente.");
        }
    }

    /**
     * Guarda el catálogo de libros como informe CSV.
     * Cada línea contiene: ID,Título,Autor,Prestado,UsuarioPrestamo
     */
    public void guardarInforme(String nombreArchivo) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            writer.write("ID,Título,Autor,Prestado,UsuarioPrestamo\n");
            for (Libro libro : libros) {
                writer.write(libro.getId() + "," + libro.getTitulo() + "," +
                             libro.getAutor() + "," + (libro.isPrestado() ? "Sí" : "No") + "," +
                             (libro.isPrestado() && libro.getUsuarioPrestamo() != null ?
                                 libro.getUsuarioPrestamo().getRut() : "") + "\n");
            }
        }
    }

    /**
     * Carga libros desde un archivo CSV (omitiendo encabezado).
     * Si el libro ya está prestado, se marca como tal.
     */
    public void cargarLibrosDesdeArchivo(String nombreArchivo) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea = reader.readLine(); // Salta encabezado
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 3) {
                    String titulo = partes[1];
                    String autor = partes[2];
                    Libro libro = new Libro(titulo, autor);
                    if (partes.length >= 4 && partes[3].equalsIgnoreCase("Sí")) {
                        libro.prestarA(null); // No hay usuario registrado en carga simple
                    }
                    agregarLibro(libro); // Usar método para mantener sincronizadas las colecciones
                }
            }
        }
    }
}