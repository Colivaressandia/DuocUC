/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UI;

import Servicio.Biblioteca;
import Excepcion.LibroYaPrestadoException;
import Excepcion.LibroNoEncontradoException;
import Modelo.Usuario;
import Modelo.Libro;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;

/**
 * Clase principal que ejecuta el menú y la lógica de la aplicación Biblioteca Duoc UC.
 * Maneja la interacción con el usuario y la validación de datos.
 * Controla el flujo principal de registro, búsqueda, préstamo y devolución de libros.
 *
 * @author Francisco Torres Palacios - Cristian Olivares Sandia
 */
public class Main {

    /**
     * Normaliza el RUT eliminando puntos, guión y espacios, y pasando a mayúscula.
     */
    public static String normalizarRut(String rut) {
        if (rut == null) return "";
        return rut.replace(".", "")
                  .replace("-", "")
                  .replace(" ", "")
                  .toUpperCase();
    }

    public static boolean validarRut(String rut) {
        return rut.matches("^\\d{1,2}\\.\\d{3}\\.\\d{3}-[\\dkK]$")
                || rut.matches("^\\d{7,8}-[\\dkK]$")
                || rut.matches("^\\d{8,9}$");
    }

    public static boolean validarNombre(String nombre) {
        return nombre != null && nombre.trim().matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,}$") && !nombre.trim().isEmpty();
    }

    public static boolean validarCorreo(String correo) {
        // Permite .com, .cl, .org, etc.
        return correo != null && correo.matches("^[^@\\s]+@[^@\\s]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean validarTelefono(String telefono) {
        return telefono != null && telefono.matches("^\\d{9}$");
    }

    public static void registrarUsuario(Biblioteca biblioteca, Scanner scanner, String rutExistente) {
        String rut;
        if (rutExistente != null) {
            rut = rutExistente;
            System.out.println("Registrando nuevo usuario con RUT: " + rut);
        } else {
            while (true) {
                System.out.print("Ingrese RUT (puede ser 12.345.678-9, 12345678-9 o 123456789): ");
                rut = scanner.nextLine();
                if (!validarRut(rut)) {
                    System.out.println("RUT inválido. Intente nuevamente.");
                    continue;
                }
                rut = normalizarRut(rut);
                if (biblioteca.getUsuarios().containsKey(rut)) {
                    System.out.println("Ese RUT ya está registrado.");
                    return;
                }
                break;
            }
        }
        rut = normalizarRut(rut);

        // Primer nombre en bucle
        String nombre;
        while (true) {
            System.out.print("Ingrese su primer nombre: ");
            nombre = scanner.nextLine();
            if (!validarNombre(nombre)) {
                System.out.println("Nombre inválido. Solo letras y espacios. Intente nuevamente.");
            } else {
                break;
            }
        }

        // Primer apellido en bucle
        String apellido;
        while (true) {
            System.out.print("Ingrese su primer apellido: ");
            apellido = scanner.nextLine();
            if (!validarNombre(apellido)) {
                System.out.println("Apellido inválido. Solo letras y espacios. Intente nuevamente.");
            } else {
                break;
            }
        }

        // Teléfono en bucle
        String telefono;
        while (true) {
            System.out.print("Ingrese su teléfono (9 dígitos): ");
            telefono = scanner.nextLine();
            if (!validarTelefono(telefono)) {
                System.out.println("Teléfono inválido. Debe tener exactamente 9 números. Intente nuevamente.");
            } else {
                break;
            }
        }

        // Correo en bucle
        String correo;
        while (true) {
            System.out.print("Ingrese su correo electrónico: ");
            correo = scanner.nextLine();
            if (!validarCorreo(correo)) {
                System.out.println("Correo inválido. Debe tener formato usuario@dominio.com/.cl/.org/etc. Intente nuevamente.");
            } else {
                break;
            }
        }

        String nombreCompleto = nombre.trim() + " " + apellido.trim();
        Usuario usuario = new Usuario(rut, nombreCompleto, telefono, correo);
        biblioteca.agregarUsuario(usuario);
        System.out.println("Usuario registrado exitosamente.");
    }

    public static void registrarUsuario(Biblioteca biblioteca, Scanner scanner) {
        registrarUsuario(biblioteca, scanner, null);
    }

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Scanner scanner = new Scanner(System.in);

        System.out.println("*************************************");
        System.out.println("*  Bienvenido(a) a la Biblioteca    *");
        System.out.println("*           Duoc UC                 *");
        System.out.println("*************************************");
        System.out.println("¡Explora, busca y renta tus libros favoritos!\n");

        biblioteca.agregarLibro(new Libro("Cien años de soledad", "Gabriel García Márquez"));
        biblioteca.agregarLibro(new Libro("Don Quijote de la Mancha", "Miguel de Cervantes"));
        biblioteca.agregarLibro(new Libro("Orgullo y prejuicio", "Jane Austen"));
        biblioteca.agregarLibro(new Libro("Moby Dick", "Herman Melville"));
        biblioteca.agregarLibro(new Libro("Crimen y castigo", "Fiódor Dostoyevski"));
        biblioteca.agregarLibro(new Libro("La Odisea", "Homero"));
        biblioteca.agregarLibro(new Libro("El Principito", "Antoine de Saint-Exupéry"));
        biblioteca.agregarLibro(new Libro("Rayuela", "Julio Cortázar"));
        biblioteca.agregarLibro(new Libro("Fahrenheit 451", "Ray Bradbury"));
        biblioteca.agregarLibro(new Libro("El Aleph", "Jorge Luis Borges"));
        biblioteca.agregarLibro(new Libro("La sombra del viento", "Carlos Ruiz Zafón"));
        biblioteca.agregarLibro(new Libro("1984", "George Orwell"));
        biblioteca.agregarLibro(new Libro("La Ilíada", "Homero"));
        biblioteca.agregarLibro(new Libro("Hamlet", "William Shakespeare"));
        biblioteca.agregarLibro(new Libro("Divina Comedia", "Dante Alighieri"));
        biblioteca.agregarLibro(new Libro("La metamorfosis", "Franz Kafka"));
        biblioteca.agregarLibro(new Libro("Madame Bovary", "Gustave Flaubert"));
        biblioteca.agregarLibro(new Libro("Anna Karenina", "León Tolstói"));
        biblioteca.agregarLibro(new Libro("Las aventuras de Huckleberry Finn", "Mark Twain"));
        biblioteca.agregarLibro(new Libro("Frankenstein", "Mary Shelley"));
        biblioteca.agregarLibro(new Libro("Drácula", "Bram Stoker"));
        biblioteca.agregarLibro(new Libro("Subterra", "Baldomero Lillo"));
        biblioteca.agregarLibro(new Libro("Hijo de ladrón", "Manuel Rojas"));
        biblioteca.agregarLibro(new Libro("Martín Rivas", "Alberto Blest Gana"));
        // Puedes agregar más libros aquí

        boolean salir = false;
        while (!salir) {
            System.out.println("\n--- Biblioteca Duoc UC ---");
            System.out.println("1. Registrar usuario");
            System.out.println("2. Catálogo");
            System.out.println("3. Buscar libro");
            System.out.println("4. Rentar libro");
            System.out.println("5. Guardar catálogo en archivo");
            System.out.println("6. Cargar catálogo desde archivo");
            System.out.println("7. Mostrar libros únicos (HashSet)");
            System.out.println("8. Mostrar catálogo ordenado (TreeSet)");
            System.out.println("9. Mostrar usuarios únicos (HashSet)");
            System.out.println("10. Mostrar usuarios ordenados (TreeSet)");
            System.out.println("11. Devolver libro");
            System.out.println("12. Salir");

            try {
                System.out.print("Seleccione opción: ");
                int opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1 -> registrarUsuario(biblioteca, scanner);
                    case 2 -> biblioteca.mostrarLibros();
                    case 3 -> {
                        System.out.print("Ingrese título o autor a buscar: ");
                        String busqueda = scanner.nextLine();
                        List<Libro> resultados = biblioteca.buscarLibros(busqueda);

                        if (resultados.isEmpty()) {
                            System.out.println("No se encontraron libros.");
                        } else {
                            System.out.println("Resultados:");
                            int i = 1;
                            for (Libro l : resultados) {
                                System.out.println(i + ". " + l);
                                i++;
                            }
                            System.out.print("¿Desea rentar uno de estos libros? (s/n): ");
                            String opcionPrestamo = scanner.nextLine();
                            if (opcionPrestamo.equalsIgnoreCase("s")) {
                                System.out.print("Ingrese el número del libro que desea rentar: ");
                                int numLibro = scanner.nextInt();
                                scanner.nextLine();
                                if (numLibro < 1 || numLibro > resultados.size()) {
                                    System.out.println("[ERROR] Número inválido.");
                                } else {
                                    Libro libroSeleccionado = resultados.get(numLibro - 1);
                                    System.out.print("Ingrese RUT usuario: ");
                                    String rut = scanner.nextLine();
                                    rut = normalizarRut(rut);
                                    if (!biblioteca.getUsuarios().containsKey(rut)) {
                                        System.out.println("El RUT no está registrado. Por favor, complete el registro:");
                                        registrarUsuario(biblioteca, scanner, rut);
                                    }
                                    try {
                                        biblioteca.prestarLibroPorId(libroSeleccionado.getId(), rut);
                                    } catch (LibroNoEncontradoException | LibroYaPrestadoException e) {
                                        System.out.println("[ERROR] " + e.getMessage());
                                    }
                                }
                            }
                        }
                    }
                    case 4 -> {
                        List<Libro> catalogo = biblioteca.getLibros();
                        if (catalogo.isEmpty()) {
                            System.out.println("No hay libros en la biblioteca.");
                        } else {
                            System.out.println("Catálogo:");
                            int i = 1;
                            for (Libro l : catalogo) {
                                System.out.println(i + ". " + l);
                                i++;
                            }
                            System.out.print("Ingrese el número del libro que desea rentar: ");
                            int numLibro = scanner.nextInt();
                            scanner.nextLine();
                            if (numLibro < 1 || numLibro > catalogo.size()) {
                                System.out.println("[ERROR] Número inválido.");
                            } else {
                                Libro libroSeleccionado = catalogo.get(numLibro - 1);
                                System.out.print("Ingrese RUT usuario: ");
                                String rut = scanner.nextLine();
                                rut = normalizarRut(rut);

                                if (!biblioteca.getUsuarios().containsKey(rut)) {
                                    System.out.println("El RUT no está registrado. Por favor, complete el registro:");
                                    registrarUsuario(biblioteca, scanner, rut);
                                }
                                try {
                                    biblioteca.prestarLibroPorId(libroSeleccionado.getId(), rut);
                                } catch (LibroNoEncontradoException | LibroYaPrestadoException e) {
                                    System.out.println("[ERROR] " + e.getMessage());
                                }
                            }
                        }
                    }
                    case 5 -> {
                        try {
                            biblioteca.guardarInforme("catalogo_biblioteca.csv");
                            System.out.println("Catálogo guardado exitosamente en catalogo_biblioteca.csv");
                        } catch (IOException e) {
                            System.out.println("Error al guardar el catálogo: " + e.getMessage());
                        }
                    }
                    case 6 -> {
                        try {
                            biblioteca.cargarLibrosDesdeArchivo("catalogo_biblioteca.csv");
                            System.out.println("Catálogo cargado exitosamente desde catalogo_biblioteca.csv");
                        } catch (IOException e) {
                            System.out.println("Error al cargar el catálogo: " + e.getMessage());
                        }
                    }
                    case 7 -> {
                        System.out.println("Libros únicos (sin repetir título y autor):");
                        if (biblioteca.getLibrosUnicos().isEmpty()) {
                            System.out.println("No hay libros en la biblioteca.");
                        } else {
                            for (Libro libro : biblioteca.getLibrosUnicos()) {
                                System.out.println(libro);
                            }
                        }
                    }
                    case 8 -> {
                        System.out.println("Catálogo ordenado (por título y autor):");
                        if (biblioteca.getCatalogoOrdenado().isEmpty()) {
                            System.out.println("No hay libros en la biblioteca.");
                        } else {
                            for (Libro libro : biblioteca.getCatalogoOrdenado()) {
                                System.out.println(libro);
                            }
                        }
                    }
                    case 9 -> {
                        System.out.println("Usuarios únicos (sin repetir RUT):");
                        if (biblioteca.getUsuariosUnicos().isEmpty()) {
                            System.out.println("No hay usuarios registrados.");
                        } else {
                            for (Usuario usuario : biblioteca.getUsuariosUnicos()) {
                                System.out.println(usuario);
                            }
                        }
                    }
                    case 10 -> {
                        System.out.println("Usuarios ordenados (por nombre completo):");
                        if (biblioteca.getUsuariosOrdenados().isEmpty()) {
                            System.out.println("No hay usuarios registrados.");
                        } else {
                            for (Usuario usuario : biblioteca.getUsuariosOrdenados()) {
                                System.out.println(usuario);
                            }
                        }
                    }
                    case 11 -> {
                        List<Libro> catalogo = biblioteca.getLibros();
                        if (catalogo.isEmpty()) {
                            System.out.println("No hay libros en la biblioteca.");
                        } else {
                            System.out.println("Catálogo:");
                            int i = 1;
                            for (Libro l : catalogo) {
                                System.out.println(i + ". " + l);
                                i++;
                            }
                            System.out.print("Ingrese el número del libro que desea devolver: ");
                            int numLibro = scanner.nextInt();
                            scanner.nextLine();
                            if (numLibro < 1 || numLibro > catalogo.size()) {
                                System.out.println("[ERROR] Número inválido.");
                            } else {
                                Libro libroSeleccionado = catalogo.get(numLibro - 1);
                                try {
                                    biblioteca.devolverLibroPorId(libroSeleccionado.getId());
                                } catch (LibroNoEncontradoException e) {
                                    System.out.println("[ERROR] " + e.getMessage());
                                }
                            }
                        }
                    }
                    case 12 -> salir = true;
                    default -> System.out.println("Opción inválida");
                }

            } catch (InputMismatchException e) {
                System.out.println("Debe ingresar un número de opción válido.");
                scanner.nextLine();
            }
        }

        scanner.close();
    }
}