/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Excepcion;

/**
 * Excepción personalizada para indicar que un libro ya está prestado y no puede ser reservado nuevamente.
 */

public class LibroYaPrestadoException extends Exception {
    public LibroYaPrestadoException(String mensaje) {
        super(mensaje);
    }
}
