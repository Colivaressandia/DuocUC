/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exp2_s5_cristian_olivares;

/**
 *
 * @author Cristian Olivares
 */

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

class Entrada {
    int numero;
    String ubicacion;
    int asiento;
    int edad;
    double precio;
    String tipo;
    int fila;

    public Entrada(int numero, String ubicacion, int fila, int asiento, int edad, double precio, String tipo) {
        this.numero = numero;
        this.ubicacion = ubicacion;
        this.fila = fila;
        this.asiento = asiento;
        this.edad = edad;
        this.precio = precio;
        this.tipo = tipo;
    }

    public void mostrar() {
        char letraFila = (char) ('A' + fila);
        System.out.println("Numero: " + numero + " | Zona: " + ubicacion + " | Asiento: " + letraFila + asiento + " | Edad: " + edad + " | Tipo: " + tipo + " | Precio: $" + precio);
    }
}

public class Exp2_S5_Cristian_Olivares {
    static ArrayList<Entrada> entradasVendidas = new ArrayList<>();
    static int contadorEntradas = 1;
    static String[][] teatro = new String[3][10];

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < teatro.length; i++) {
            for (int j = 0; j < teatro[i].length; j++) {
                teatro[i][j] = "[ ]";
            }
        }

        while (true) {
            System.out.println("\n--- Menu Principal ---");
            System.out.println("Bienvenidos al Teatro Moro");
            System.out.println("1: Venta de entrada");
            System.out.println("2: Ver promociones");
            System.out.println("3: Buscar entrada");
            System.out.println("4: Eliminar entrada");
            System.out.println("5: Salir");
            System.out.println("6: Ver todas las entradas vendidas");
            System.out.print("Seleccione una opcion: ");
            String opcion = sc.nextLine();

            switch (opcion) {
                case "1" -> venderEntrada(sc);
                case "2" -> mostrarPromociones();
                case "3" -> buscarEntrada(sc);
                case "4" -> eliminarEntrada(sc);
                case "5" -> {
                    System.out.println("Gracias por usar la aplicacion.");
                    return;
                }
                case "6" -> mostrarTodasEntradas();
                default -> System.out.println("Opcion invalida. Intente nuevamente.");
            }
        }
    }

    static void venderEntrada(Scanner sc) {
        System.out.println("\n--- Venta de Entrada ---");
        int cantidadEntradas;
        while (true) {
            try {
                System.out.print("¿Cuantas entradas desea comprar?: ");
                cantidadEntradas = Integer.parseInt(sc.nextLine());
                if (cantidadEntradas >= 1 && cantidadEntradas <= 10) break;
                else System.out.println("Cantidad no valida (1 a 10).");
            } catch (Exception e) {
                System.out.println("Entrada invalida.");
            }
        }

        for (int i = 0; i < cantidadEntradas; i++) {
            System.out.println("\n--- Entrada #" + (i + 1) + " ---");

            String ubicacion;
            while (true) {
                System.out.print("Seleccione la zona (VIP, Platea, General): ");
                ubicacion = sc.nextLine().toUpperCase();
                if (ubicacion.equals("VIP") || ubicacion.equals("PLATEA") || ubicacion.equals("GENERAL")) break;
                System.out.println("Zona invalida.");
            }

            mostrarPlano();

            int fila = -1, columna = -1;
            while (true) {
                System.out.print("Ingrese el identificador del asiento (ej: A1, B3, C10): ");
                String asientoInput = sc.nextLine().toUpperCase();

                if (asientoInput.matches("^[ABC][1-9]0?$")) {
                    char filaChar = asientoInput.charAt(0);
                    int numAsiento = Integer.parseInt(asientoInput.substring(1));
                    fila = filaChar - 'A';
                    columna = numAsiento - 1;

                    if (teatro[fila][columna].equals("[X]")) {
                        System.out.println("Ese asiento ya esta ocupado. Elija otro.");
                    } else {
                        teatro[fila][columna] = "[X]";
                        break;
                    }
                } else {
                    System.out.println("Formato invalido. Use A1, B2, C3, etc.");
                }
            }

            int edad;
            while (true) {
                try {
                    System.out.print("Ingrese su edad: ");
                    edad = Integer.parseInt(sc.nextLine());
                    if (edad > 0 && edad < 120) break;
                    else System.out.println("Edad no valida.");
                } catch (Exception e) {
                    System.out.println("Entrada invalida.");
                }
            }

            double precioBase = switch (ubicacion) {
                case "VIP" -> 20000;
                case "PLATEA" -> 15000;
                case "GENERAL" -> 10000;
                default -> 0;
            };

            double descuento = 0;
            String tipo = "Normal";

            if (edad >= 65) {
                descuento = 0.15;
                tipo = "Tercera edad";
            } else if (edad < 25) {
                descuento = 0.10;
                tipo = "Estudiante";
            }

            double precioFinal = precioBase - (precioBase * descuento);
            Entrada nueva = new Entrada(contadorEntradas++, ubicacion, fila, columna + 1, edad, precioFinal, tipo);
            entradasVendidas.add(nueva);
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String fechaHora = LocalDateTime.now().format(formatter);
        System.out.println("\n--- Resumen de la Compra ---");
        System.out.println("Fecha: " + fechaHora);
        System.out.println("Gracias por su compra");
        for (int i = entradasVendidas.size() - cantidadEntradas; i < entradasVendidas.size(); i++) {
            entradasVendidas.get(i).mostrar();
        }

        if (cantidadEntradas >= 2) {
            System.out.println("\n¡Promoción activa! 2 bebidas 500ml y 2 papas fritas gratis.");
        }

        mostrarPlano();

        System.out.print("\n¿Desea seguir comprando entradas? (s/n): ");
        String seguir = sc.nextLine().toLowerCase();
        if (seguir.equals("s")) {
            venderEntrada(sc);
        }
    }

    static void mostrarPlano() {
        System.out.println("\n--- Plano del Teatro ---");
        for (int i = 0; i < teatro.length; i++) {
            char letra = (char) ('A' + i);
            System.out.print("Fila " + letra + ": ");
            for (int j = 0; j < teatro[i].length; j++) {
                if (teatro[i][j].equals("[X]")) {
                    System.out.print("[X] ");
                } else {
                    System.out.print("[" + letra + (j + 1) + "] ");
                }
            }
            System.out.println();
        }
    }

    static void mostrarPromociones() {
        System.out.println("\n--- Promociones Disponibles ---");
        System.out.println("- 10% de descuento para estudiantes (< 25 anos)");
        System.out.println("- 15% de descuento para tercera edad (65+ anos)");
        System.out.println("- Por comprar 2 o más entradas: bebidas + snacks gratis");
    }

    static void buscarEntrada(Scanner sc) {
        System.out.println("\n--- Buscar Entrada ---");
        System.out.println("1: Por numero\n2: Por ubicacion\n3: Por tipo");
        System.out.print("Seleccione una opcion: ");
        String opcion = sc.nextLine();

        switch (opcion) {
            case "1" -> {
                try {
                    System.out.print("Ingrese el numero de entrada: ");
                    int numero = Integer.parseInt(sc.nextLine());
                    for (Entrada e : entradasVendidas) {
                        if (e.numero == numero) {
                            e.mostrar();
                            return;
                        }
                    }
                    System.out.println("Entrada no encontrada.");
                } catch (Exception e) {
                    System.out.println("Numero invalido.");
                }
            }
            case "2" -> {
                System.out.print("Ingrese la ubicacion (VIP, Platea, General): ");
                String ubi = sc.nextLine().toUpperCase();
                for (Entrada e : entradasVendidas) {
                    if (e.ubicacion.equals(ubi)) e.mostrar();
                }
            }
            case "3" -> {
                System.out.print("Ingrese el tipo (Estudiante o Tercera edad): ");
                String tipo = sc.nextLine();
                for (Entrada e : entradasVendidas) {
                    if (e.tipo.equalsIgnoreCase(tipo)) e.mostrar();
                }
            }
            default -> System.out.println("Opcion invalida.");
        }
    }

    static void eliminarEntrada(Scanner sc) {
        System.out.print("\nIngrese el numero de la entrada a eliminar: ");
        try {
            int numero = Integer.parseInt(sc.nextLine());
            for (Entrada e : entradasVendidas) {
                if (e.numero == numero) {
                    entradasVendidas.remove(e);
                    teatro[e.fila][e.asiento - 1] = "[ ]";
                    System.out.println("Entrada eliminada y asiento liberado.");
                    return;
                }
            }
            System.out.println("Entrada no encontrada.");
        } catch (Exception e) {
            System.out.println("Numero invalido.");
        }
    }

    static void mostrarTodasEntradas() {
        if (entradasVendidas.isEmpty()) {
            System.out.println("\nNo hay entradas vendidas.");
        } else {
            System.out.println("\n--- Entradas Vendidas ---");
            for (Entrada e : entradasVendidas) {
                e.mostrar();
            }
        }
    }
}













  