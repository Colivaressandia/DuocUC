/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exp3_s9_cristian_olivares;

/**
 *
 * @author Cristian Olivares Sandia
 */

import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;


// 1: Clase principal del sistema teatro
public class Exp3_S9_Cristian_Olivares {
    // Configuración de debug
    private static final boolean DEBUG_MODE = true;
    private static final String DEBUG_LOG_FILE = "teatro_debug.log";
    private static PrintWriter debugLogger;
    
    static {
        try {
            debugLogger = new PrintWriter(new FileWriter(DEBUG_LOG_FILE, true));
            debugLogger.println("\n=== NEW DEBUG SESSION ===");
            debugLogger.println("Initialized at: " + LocalDateTime.now());
        } catch (IOException e) {
            System.err.println("Failed to initialize debug logger: " + e.getMessage());
        }
    }

    // 2: Enumeraciones para estados y zonas
    private enum EstadoAsiento {
        DISPONIBLE("[ ]"), 
        RESERVADO("[R]"), 
        VENDIDO("[X]");
        
        private final String simbolo;
        
        EstadoAsiento(String simbolo) {
            this.simbolo = simbolo;
        }
        
        public String getSimbolo() {
            return simbolo;
        }
    }

    private enum Zona {
        VIP("VIP", 20000), 
        PLATEA("PLATEA", 15000), 
        GENERAL("GENERAL", 10000);
        
        private final String nombre;
        private final double precio;
        
        Zona(String nombre, double precio) {
            this.nombre = nombre;
            this.precio = precio;
        }
        
        public String getNombre() {
            return nombre;
        }
        
        public double getPrecio() {
            return precio;
        }
    }

     // 3: Constantes de configuración del sistema
    private static final String NOMBRE_TEATRO = "Teatro Moro";
    private static final String ARCHIVO_DATOS = "teatro_moro.dat";
    private static final int TIEMPO_RESERVA_MINUTOS = 30;
    private static final int FILAS = 3;
    private static final int ASIENTOS_POR_FILA = 10;
    private static final DateTimeFormatter DATE_FORMATTER = 
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    private static final String EMAIL_REGEX = "^[\\w.-]+@([\\w-]+\\.)+[\\w-]{2,63}$";

    // 4: Estructuras de datos principales
    private final Map<String, Asiento> mapaAsientos = new HashMap<>();
    private final List<Evento> eventos = new ArrayList<>();
    private final List<Cliente> clientes = new ArrayList<>();
    private final List<Promocion> promociones = new ArrayList<>();
    private final List<Transaccion> transacciones = new ArrayList<>();
    private final Estadisticas estadisticas = new Estadisticas();
    private final Scanner scanner = new Scanner(System.in);
    
    // Mejora aplicada 1: Mejor sistema de búsqueda de reservas
    private final Map<String, Transaccion> reservasPorAsiento = new HashMap<>();
    private final List<Transaccion> reservasActivas = new ArrayList<>();
    
    // Mejorar aplicada 2: Cache optimizado
    private final Map<String, Object> cache = new HashMap<>();

    public static void main(String[] args) {
        Exp3_S9_Cristian_Olivares sistema = new Exp3_S9_Cristian_Olivares();
        sistema.inicializarSistema();
        sistema.mostrarMenuPrincipal();
        
        // Mejora aplicada 3: Cierre seguro de recursos
        if (debugLogger != null) {
            debugLogger.println("=== END OF SESSION ===");
            debugLogger.close();
        }
    }

    // 5: Métodos de debug
    private void debugLog(String message) {
        if (DEBUG_MODE) {
            String timestamp = LocalDateTime.now().format(DATE_FORMATTER);
            String logMessage = "[" + timestamp + "] " + message;
            
            if (debugLogger != null) {
                debugLogger.println(logMessage);
                debugLogger.flush();
            }
        }
    }
    
    private void dumpSystemState() {
        if (!DEBUG_MODE) return;
        
        debugLog("=== SYSTEM STATE DUMP ===");
        debugLog("Eventos: " + eventos.size());
        eventos.forEach(e -> debugLog(" - " + e.getNombre() + " (" + e.getFunciones().size() + " funciones)"));
        
        debugLog("Clientes: " + clientes.size());
        debugLog("Promociones: " + promociones.size());
        debugLog("Transacciones: " + transacciones.size());
        debugLog("Reservas activas: " + reservasActivas.size());
        
        debugLog("Estadísticas:");
        debugLog(" - Entradas vendidas: " + estadisticas.getTotalVendidas());
        debugLog(" - Ingresos: $" + estadisticas.getIngresosTotales());
        debugLog(" - Bebidas regaladas: " + estadisticas.getBebidasRegaladas());
    }

    // 6: Clases internas
    static class Asiento implements Serializable {
        private final String codigo;
        private EstadoAsiento estado;
        private final Zona zona;
        private Cliente cliente;
        
        public Asiento(String codigo, Zona zona) {
            this.codigo = codigo;
            this.estado = EstadoAsiento.DISPONIBLE;
            this.zona = zona;
            this.cliente = null;
        }
        
        public String getCodigo() {
            return codigo;
        }
        
        public EstadoAsiento getEstado() {
            return estado;
        }
        
        public void setEstado(EstadoAsiento estado) {
            this.estado = estado;
        }
        
        public Zona getZona() {
            return zona;
        }
        
        public Cliente getCliente() {
            return cliente;
        }
        
        public void setCliente(Cliente cliente) {
            this.cliente = cliente;
        }
        
        public boolean estaDisponible() {
            return estado == EstadoAsiento.DISPONIBLE;
        }
        
        public boolean estaReservado() {
            return estado == EstadoAsiento.RESERVADO;
        }
        
        public boolean estaVendido() {
            return estado == EstadoAsiento.VENDIDO;
        }
    }

    static class Evento implements Serializable {
        private final String nombre;
        private final LocalDate fecha;
        private final List<Funcion> funciones;
        
        public Evento(String nombre, LocalDate fecha) {
            this.nombre = nombre;
            this.fecha = fecha;
            this.funciones = new ArrayList<>();
        }
        
        public String getNombre() {
            return nombre;
        }
        
        public LocalDate getFecha() {
            return fecha;
        }
        
        public List<Funcion> getFunciones() {
            return funciones;
        }
        
        public void agregarFuncion(Funcion funcion) {
            funciones.add(funcion);
        }
    }

    static class Funcion implements Serializable {
        private final LocalDateTime fechaHora;
        private final Map<String, Asiento> asientos;
        
        public Funcion(LocalDateTime fechaHora) {
            this.fechaHora = fechaHora;
            this.asientos = new HashMap<>();
            inicializarAsientos();
        }
        
        public LocalDateTime getFechaHora() {
            return fechaHora;
        }
        
        public Map<String, Asiento> getAsientos() {
            return asientos;
        }
        
        private void inicializarAsientos() {
            for (Zona zona : Zona.values()) {
                for (int i = 1; i <= ASIENTOS_POR_FILA; i++) {
                    String codigo = zona.name().charAt(0) + String.valueOf(i);
                    asientos.put(codigo, new Asiento(codigo, zona));
                }
            }
        }
        
        public Asiento getAsiento(String codigo) {
            return asientos.get(codigo);
        }
        
        public List<Asiento> getAsientosDisponibles() {
            return asientos.values().stream()
                .filter(Asiento::estaDisponible)
                .collect(Collectors.toList());
        }
    }

    static class Cliente implements Serializable, Comparable<Cliente> {
        private final int id;
        private final String nombre;
        private final int edad;
        private final String email;
        private final char genero; // M (Masculino ) F (Femenino)
        private final boolean estudiante; 
        
        public Cliente(int id, String nombre, int edad, String email, char genero, boolean estudiante) {
            this.id = id;
            this.nombre = nombre;
            this.edad = edad;
            this.email = email;
            this.genero = genero;
            this. estudiante = estudiante;
        }
        
        public int getId() {
            return id;
        }
        
        public String getNombre() {
            return nombre;
        }
        
        public int getEdad() {
            return edad;
        }
        
        public String getEmail() {
            return email;
        }
        
        public boolean esEstudiante() {
            return estudiante;
        }
        
        public boolean esTerceraEdad() {
            return edad >= 65;
        }
        
        public boolean esNino() {
            return edad < 12;
        }
        
        public char getGenero() {
            return genero;
        }
        
        @Override
        public int compareTo(Cliente otro) {
            return this.nombre.compareTo(otro.nombre);
        }
        
        @Override
        public String toString() {
            return String.format("ID: %d, Nombre: %s, Edad: %d, Email: %s, Genero: %c, Estudiante: %b" , id, nombre, edad, email,genero,estudiante);
        }
    }

    static class Transaccion implements Serializable {
        private final long id;
        private final LocalDateTime fecha;
        private LocalDateTime fechaReserva;
        private final Cliente cliente;
        private final List<Entrada> entradas;
        private double total;
        private String estado;
        
        public Transaccion(long id, Cliente cliente) {
            this.id = id;
            this.fecha = LocalDateTime.now();
            this.fechaReserva = LocalDateTime.now();
            this.cliente = cliente;
            this.entradas = new ArrayList<>();
            this.total = 0;
            this.estado = "Pendiente";
        }
        
        public long getId() {
            return id;
        }
        
        public LocalDateTime getFecha() {
            return fecha;
        }
        
        public LocalDateTime getFechaReserva() {
            return fechaReserva;
        }
        
        public void setFechaReserva(LocalDateTime fechaReserva) {
            this.fechaReserva = fechaReserva;
        }
        
        public Cliente getCliente() {
            return cliente;
        }
        
        public List<Entrada> getEntradas() {
            return entradas;
        }
        
        public double getTotal() {
            return total;
        }
        
        public String getEstado() {
            return estado;
        }
        
        public void setEstado(String estado) {
            this.estado = estado;
        }
        
        public void agregarEntrada(Entrada entrada) {
            entradas.add(entrada);
            total += entrada.getprecioFinal();
        }
    }

    static class Entrada implements Serializable {
        private final String codigoAsiento;
        private final Zona zona;
        private final double precioOriginal;
        private final double descuentoAplicado;
        private final String tipoDescuento;
        private final double precioFinal;
        private final LocalDateTime fechaCompra;
        private String estado;
        private Cliente cliente;
        
        public Entrada(String codigoAsiento, Zona zona, double precioOriginal, double descuentoAplicado, String tipoDescuento) {
            this.codigoAsiento = codigoAsiento;
            this.zona = zona;
            this.precioOriginal = precioOriginal;
            this.descuentoAplicado = descuentoAplicado;
            this.tipoDescuento = tipoDescuento;
            this.precioFinal = precioOriginal * (1 - descuentoAplicado);
            this.fechaCompra = LocalDateTime.now();
            this.estado = "Reservado";
            this.cliente = null;
        }
        
        public String getCodigoAsiento() {
            return codigoAsiento;
        }
        
        public Zona getZona() {
            return zona;
        }
        
        public double getPrecioOriginal() {
            return precioOriginal;
        }
        
        public double getDescuentoAplicado() {
            return descuentoAplicado;
        }
        
        public double getprecioFinal(){
            return precioFinal;
        }
        
        public String getTipoDescuento() {
            return tipoDescuento;
        }
        
        public LocalDateTime getFechaCompra() {
            return fechaCompra;
        }
        
        public String getEstado() {
            return estado;
        }
        
        public void setEstado(String estado) {
            this.estado = estado;
        }
        
        public Cliente getCliente() {
            return cliente;
        }
        
        public void setCliente(Cliente cliente) {
            this.cliente = cliente;
        }
    }

    static class Promocion implements Serializable {
        private final String nombre;
        private final String descripcion;
        private final double descuento;
        private final Predicate<Cliente> criterio;
        
        public Promocion(String nombre, String descripcion, double descuento, Predicate<Cliente> criterio) {
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.descuento = descuento;
            this.criterio = criterio;
        }
        
        public String getNombre() {
            return nombre;
        }
        
        public String getDescripcion() {
            return descripcion;
        }
        
        public double getDescuento() {
            return descuento;
        }
        
        public boolean aplica(Cliente cliente) {
            return criterio.test(cliente);
        }
        
        public double aplicarDescuento(double precio) {
            return precio * (1 - descuento);
        }
    }

    static class Estadisticas implements Serializable {
        private int totalVendidas;
        private double ingresosTotales;
        private int reservasActivas;
        private int reservasConvertidas;
        private int bebidasRegaladas;
        
        public int getTotalVendidas() {
            return totalVendidas;
        }
        
        public double getIngresosTotales() {
            return ingresosTotales;
        }
        
        public int getReservasActivas() {
            return reservasActivas;
        }
        
        public int getReservasConvertidas() {
            return reservasConvertidas;
        }
        
        public int getBebidasRegaladas() {
            return bebidasRegaladas;
        }
        
        public void incrementarVentas(int cantidad) {
            totalVendidas += cantidad;
        }
        
        public void agregarIngresos(double monto) {
            ingresosTotales += monto;
        }
        
        public void incrementarReservasActivas(int cantidad) {
            reservasActivas += cantidad;
        }
        
        public void incrementarReservasConvertidas(int cantidad) {
            reservasConvertidas += cantidad;
        }
        
        public void incrementarBebidasRegaladas(int cantidad) {
            bebidasRegaladas += cantidad;
        }
    }

    // 7: Métodos principales del sistema
    private void inicializarSistema() {
        debugLog("Inicializando sistema...");
        cargarDatos();
        
        if (eventos.isEmpty()) {
            debugLog("No se encontraron eventos, creando eventos iniciales");
            crearEventosIniciales();
        }
        
        if (promociones.isEmpty()) {
            debugLog("No se encontraron promociones, inicializando promociones predeterminadas");
            inicializarPromociones();
        }
        
        debugLog("Iniciando tarea de liberación de reservas");
        iniciarTareaLiberacionReservas();
        
        // Mejora aplicada 4: Prueba de carga inicial
        if (DEBUG_MODE) {
            pruebaDeCarga();
        }
        
        dumpSystemState();
    }

    // Mejora aplicada 5: Prueba de carga del sistema
    private void pruebaDeCarga() {
        debugLog("Iniciando prueba de carga...");
        long inicio = System.currentTimeMillis();
        
        // Simular 1000 clientes
        for (int i = 0; i < 1000; i++) {
            char generoPrueba = (i % 3 == 0) ? 'F' : 'M';
            boolean estudiantePrueba = (i % 2 == 0);
            clientes.add(new Cliente(i+1, "ClientePrueba"+i, 20+i%50, "test"+i+"@test.com", generoPrueba, estudiantePrueba));
        }
        
        // Simular 100 transacciones
        Random rand = new Random();
        for (int i = 0; i < 100; i++) {
            Cliente cliente = clientes.get(rand.nextInt(clientes.size()));
            Transaccion t = new Transaccion(transacciones.size()+1, cliente);
            
            int numEntradas = 1 + rand.nextInt(4);
            for (int j = 0; j < numEntradas; j++) {
                Zona zona = Zona.values()[rand.nextInt(Zona.values().length)];
                String codigoAsiento = zona.name().charAt(0) + String.valueOf(1 + rand.nextInt(ASIENTOS_POR_FILA));
                Object[] resultadoPrecio = calcularPrecioFinalConDescuento(zona, cliente);
                double precioFinal = (double) resultadoPrecio[0];
                double descuentoAplicado = (double) resultadoPrecio[1];
                String tipoDescuento = (String) resultadoPrecio[2];
                double precioOriginal = zona.getPrecio();
                t.agregarEntrada(new Entrada(codigoAsiento, zona, precioOriginal, descuentoAplicado, tipoDescuento));
            }
            
            transacciones.add(t);
        }
        
        long fin = System.currentTimeMillis();
        debugLog("Prueba de carga completada. Tiempo: " + (fin - inicio) + "ms");
        debugLog("Clientes: " + clientes.size() + ", Transacciones: " + transacciones.size());
    }

    private void crearEventosIniciales() {
        debugLog("Creando eventos iniciales...");
        Evento concierto = new Evento("Concierto Sinfónico", LocalDate.now().plusDays(7));
        concierto.agregarFuncion(new Funcion(LocalDateTime.now().plusDays(7).withHour(20).withMinute(0)));
        
        eventos.add(concierto);
        debugLog("Evento inicial creado: " + concierto.getNombre());
    }

    private void inicializarPromociones() {
        debugLog("Inicializando promociones predeterminadas...");
        
        promociones.add (new Promocion(
           "Niños",
           "10% para menores de 12 años",
            0.10,
            Cliente::esNino 
        ));
        
        promociones.add(new Promocion(
        "Mujer", 
        "20% de descuento para clientes del género femenino", 
        0.20, 
        c -> c.getGenero() == 'F'
        ));
        
                
        promociones.add(new Promocion(
            "Estudiante", 
            "15% de descuento para Estudiantes", 
            0.15, 
            Cliente::esEstudiante
        ));
        
        promociones.add(new Promocion(
            "Tercera Edad", 
            "25% de descuento para mayores de 65 años", 
            0.25, 
            Cliente::esTerceraEdad
        ));
        
        promociones.add(new Promocion(
            "Grupo Familiar", 
            "2 bebidas gratis por compra de 2+ entradas", 
            0.0, 
            c -> true
        ));
        
        debugLog("Promociones inicializadas: " + promociones.size());
    }
    
    private Evento obtenerEventoCacheado(int id) {
        String clave = "evento_" + id;
        if (cache.containsKey(clave)) {  // Corregido: cambiado 'clue' por 'clave'
        debugLog("Evento obtenido de cache: " + clave);
        return (Evento) cache.get(clave);
        }
        
        if (id > 0 && id <= eventos.size()) {
            Evento evento = eventos.get(id - 1);
            cache.put(clave, evento);
            debugLog("Evento añadido a cache: " + clave);
            return evento;
        }
        
        debugLog("ID de evento no válido: " + id);
        return null;
    }
    
    private void limpiarCacheEventos() {
        int sizeBefore = cache.size();
        cache.keySet().removeIf(key -> key.startsWith("evento_"));
        debugLog("Cache limpiado. Elementos eliminados: " + (sizeBefore - cache.size()));
    }

    private void listarEventosPaginados() {
        debugLog("Listando eventos paginados...");
        System.out.print("\nIngrese número de página (5 eventos por página): ");
        int pagina = scanner.nextInt();
        scanner.nextLine();
        
        int inicio = (pagina - 1) * 5;
        int fin = Math.min(inicio + 5, eventos.size());
        
        if (inicio >= eventos.size() || inicio < 0) {
            debugLog("Intento de acceso a página inválida: " + pagina);
            System.out.println("Página no válida");
            return;
        }
        
        debugLog("Mostrando página " + pagina + " (eventos " + (inicio+1) + " a " + fin + ")");
        System.out.println("\n=== EVENTOS (Página " + pagina + ") ===");
        for (int i = inicio; i < fin; i++) {
            Evento evento = eventos.get(i);
            System.out.printf("%d. %s - %s\n", 
                i+1, evento.getNombre(), evento.getFecha().format(DateTimeFormatter.ISO_LOCAL_DATE));
        }
        
        System.out.printf("\nMostrando %d-%d de %d eventos\n", 
            inicio+1, fin, eventos.size());
    }

    // MEJORA #6: Optimización del sistema de reservas
    private void iniciarTareaLiberacionReservas() {
        debugLog("Programando tarea de liberación de reservas...");
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                debugLog("Ejecutando tarea programada de liberación de reservas");
                liberarReservasExpiradasOptimizado();
            }
        }, 0, 30 * 60 * 1000); // Ejecutar cada 30 minutos
    }
    
    private void liberarReservasExpiradasOptimizado() {
        debugLog("Iniciando liberación de reservas expiradas...");
        LocalDateTime ahora = LocalDateTime.now();
        int liberadas = 0;
        
        Iterator<Transaccion> iterator = reservasActivas.iterator();
        while (iterator.hasNext()) {
            Transaccion t = iterator.next();
            Duration duracion = Duration.between(t.getFechaReserva(), ahora);
            long minutos = duracion.toMinutes();
            
            if (minutos >= TIEMPO_RESERVA_MINUTOS) {
                debugLog("Liberando reserva expirada ID: " + t.getId() + " - Cliente: " + t.getCliente().getNombre());
                t.setEstado("Cancelado");
                
                // MEJORA #7: Eliminar de mapa de reservas por asiento
                for (Entrada e : t.getEntradas()) {
                    reservasPorAsiento.remove(e.getCodigoAsiento());
                }
                
                iterator.remove();
                liberadas++;
                estadisticas.incrementarReservasActivas(-1);
                
                for (Entrada e : t.getEntradas()) {
                    for (Evento evento : eventos) {
                        for (Funcion f : evento.getFunciones()) {
                            Asiento a = f.getAsiento(e.getCodigoAsiento());
                            if (a != null && a.estaReservado()) {
                                a.setEstado(EstadoAsiento.DISPONIBLE);
                                a.setCliente(null);
                                debugLog("Asiento liberado: " + e.getCodigoAsiento());
                            }
                        }
                    }
                }
            }
        }
        
        if (liberadas > 0) {
            debugLog("Reservas liberadas: " + liberadas);
            System.out.println("\n[System] Se liberaron " + liberadas + " reservas expiradas automáticamente");
        } else {
            debugLog("No se encontraron reservas expiradas");
        }
    }
    
    private void agregarReserva(Transaccion transaccion) {
        debugLog("Agregando nueva reserva ID: " + transaccion.getId() + " - Cliente: " + transaccion.getCliente().getNombre());
        transaccion.setEstado("Reservado");
        transaccion.setFechaReserva(LocalDateTime.now());
        transacciones.add(transaccion);
        reservasActivas.add(transaccion);
        
        // MEJORA #8: Agregar al mapa de reservas por asiento
        for (Entrada e : transaccion.getEntradas()) {
            reservasPorAsiento.put(e.getCodigoAsiento(), transaccion);
        }
        
        estadisticas.incrementarReservasActivas(1);
        debugLog("Reserva agregada exitosamente. Total reservas activas: " + reservasActivas.size());
    }

    private void mostrarMenuPrincipal() {
        int opcion;
        do {
            debugLog("Mostrando menú principal");
            System.out.println("\n=== " + NOMBRE_TEATRO + " ===");
            System.out.println("=== MENÚ PRINCIPAL ===");
            System.out.println("1. Gestión de Eventos");
            System.out.println("2. Venta de Entradas");
            System.out.println("3. Gestión de Reservas");
            System.out.println("4. Reportes y Estadísticas");
            System.out.println("5. Administración del Sistema");
            System.out.println("6. Salir");
            System.out.println("==============================================");
            
            opcion = leerOpcion(1, 6);

            switch (opcion) {
                case 1 -> gestionarEventos();
                case 2 -> realizarVenta();
                case 3 -> gestionarReservas();
                case 4 -> mostrarReportes();
                case 5 -> administrarSistema();
                case 6 -> {
                    debugLog("Saliendo del sistema...");
                    guardarDatos();
                    System.out.println("Gracias por usar el sistema del " + NOMBRE_TEATRO);
                }
            }
        } while (opcion != 6);
    }

     // 8 Métodos para gestión de eventos
    private void gestionarEventos() {
        debugLog("Accediendo a gestión de eventos");
        System.out.println("\n--- GESTIÓN DE EVENTOS ---");
        System.out.println("1. Crear nuevo evento");
        System.out.println("2. Agregar función a evento");
        System.out.println("3. Listar eventos (paginado)");
        System.out.println("4. Limpiar cache de eventos");
        System.out.println("5. Volver");
        
        int opcion = leerOpcion(1, 5);
        
        switch (opcion) {
            case 1 -> crearEvento();
            case 2 -> agregarFuncion();
            case 3 -> listarEventosPaginados();
            case 4 -> {
                limpiarCacheEventos();
                System.out.println("Cache de eventos limpiado");
            }
        }
    }

    
    /**
 * Proceso completo para vender entradas:
 * - Selecciona evento y función
 * - Muestra asientos disponibles
 * - Registra cliente si es nuevo
 * - Aplica promociones
 */
    // 9 Métodos venta de entradas
    private void realizarVenta() {
        debugLog("Iniciando proceso de venta");
        listarEventosPaginados();
        System.out.print("Seleccione evento: ");
        int opcionEvento = scanner.nextInt();
        scanner.nextLine();
        
        Evento evento = obtenerEventoCacheado(opcionEvento);
        if (evento == null) {
            debugLog("Evento seleccionado no válido: " + opcionEvento);
            System.out.println("Evento no válido");
            return;
        }
        
        if (evento.getFunciones().isEmpty()) {
            debugLog("Evento no tiene funciones: " + evento.getNombre());
            System.out.println("No hay funciones para este evento");
            return;
        }
        
        System.out.println("\nFunciones disponibles:");
        for (int i = 0; i < evento.getFunciones().size(); i++) {
            System.out.printf("%d. %s\n", 
                i+1, 
                evento.getFunciones().get(i).getFechaHora().format(DATE_FORMATTER));
        }
        
        System.out.print("Seleccione función: ");
        int opcionFuncion = scanner.nextInt();
        scanner.nextLine();
        
        if (opcionFuncion < 1 || opcionFuncion > evento.getFunciones().size()) {
            debugLog("Función seleccionada no válida: " + opcionFuncion);
            System.out.println("Función no válida");
            return;
        }
        
        Funcion funcion = evento.getFunciones().get(opcionFuncion - 1);
        debugLog("Función seleccionada: " + funcion.getFechaHora().format(DATE_FORMATTER));
        
        Cliente cliente = registrarCliente();
        if (cliente == null) {
            debugLog("Registro de cliente fallido");
            return;
        }
        
        Transaccion transaccion = new Transaccion(transacciones.size() + 1, cliente);
        debugLog("Nueva transacción creada ID: " + transaccion.getId());
        
        boolean continuar = true;
        while (continuar) {
            mostrarPlanoAsientos(funcion);
            
            System.out.print("Ingrese asiento a comprar (ej: V1, P5, G10): ");
            String codigoAsiento = scanner.nextLine().toUpperCase();
            
            if (!validarFormatoAsiento(codigoAsiento)) {
                debugLog("Formato de asiento inválido: " + codigoAsiento);
                System.out.println("Error: Asiento inválido. Debe ser V, P o G seguido de número (1-10)");
                System.out.println("Ejemplos válidos: V1, P5, G10");
                continue;
            }
            
            Asiento asiento = funcion.getAsiento(codigoAsiento);
            if (asiento == null) {
                debugLog("Asiento no existe: " + codigoAsiento);
                System.out.println("Asiento no existe");
                continue;
            }
            
            if (!asiento.estaDisponible()) {
                debugLog("Asiento no disponible: " + codigoAsiento + " - Estado: " + asiento.getEstado());
                System.out.println("Asiento no disponible");
                continue;
            }
            
            Object[] resultadoPrecio = calcularPrecioFinalConDescuento(asiento.getZona(), cliente);
            double precioFinal = (double) resultadoPrecio[0];
            double descuentoAplicado = (double) resultadoPrecio[1];
            String tipoDescuento = (String) resultadoPrecio[2];
            double precioOriginal = asiento.getZona().getPrecio();
            
            Entrada entrada = new Entrada(codigoAsiento, asiento.getZona(), precioOriginal, descuentoAplicado, tipoDescuento);
            entrada.setCliente(cliente);
            entrada.setEstado("Comprado");
            
            transaccion.agregarEntrada(entrada);
            
            asiento.setEstado(EstadoAsiento.VENDIDO);
            asiento.setCliente(cliente);
            
            debugLog("Asiento vendido: " + codigoAsiento + " - Precio: " + precioFinal);
            System.out.printf("Asiento %s (%s) agregado por $%.2f\n", 
                codigoAsiento, asiento.getZona().getNombre(), precioFinal);
            
            continuar = confirmar("¿Desea agregar otro asiento?");
        }
        
        aplicarPromociones(transaccion);
        transaccion.setEstado("Completada");
        transacciones.add(transaccion);
        
        actualizarEstadisticas(transaccion);
        imprimirBoleta(transaccion);
        debugLog("Venta completada. Total: " + transaccion.getTotal());
    }

    private void guardarDatos() {
        debugLog("Guardando datos del sistema...");
        try (ObjectOutputStream oos = new ObjectOutputStream(
             new FileOutputStream(ARCHIVO_DATOS))) {
            
            Map<String, Object> datos = new HashMap<>();
            datos.put("eventos", eventos);
            datos.put("clientes", clientes);
            datos.put("promociones", promociones);
            datos.put("transacciones", transacciones);
            datos.put("reservasActivas", reservasActivas);
            datos.put("reservasPorAsiento", reservasPorAsiento); // MEJORA #9: Guardar mapa de reservas
            datos.put("estadisticas", estadisticas);
            
            oos.writeObject(datos);
            debugLog("Datos guardados exitosamente en " + ARCHIVO_DATOS);
        } catch (IOException e) {
            debugLog("Error al guardar datos: " + e.getMessage());
            System.err.println("Error al guardar datos: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void cargarDatos() {
        debugLog("Cargando datos del sistema...");
        File archivo = new File(ARCHIVO_DATOS);
        if (!archivo.exists()) {
            debugLog("Archivo de datos no encontrado, se creará uno nuevo");
            return;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(
             new FileInputStream(archivo))) {
            
            Map<String, Object> datos = (Map<String, Object>) ois.readObject();
            eventos.clear();
            eventos.addAll((List<Evento>) datos.get("eventos"));
            clientes.clear();
            clientes.addAll((List<Cliente>) datos.get("clientes"));
            promociones.clear();
            promociones.addAll((List<Promocion>) datos.get("promociones"));
            transacciones.clear();
            transacciones.addAll((List<Transaccion>) datos.get("transacciones"));
            reservasActivas.clear();
            reservasActivas.addAll((List<Transaccion>) datos.getOrDefault("reservasActivas", new ArrayList<>()));
            
            // Mejora aplicada 10: Cargar mapa de reservas
            reservasPorAsiento.clear();
            if (datos.containsKey("reservasPorAsiento")) {
                reservasPorAsiento.putAll((Map<String, Transaccion>) datos.get("reservasPorAsiento"));
            }
            
            Estadisticas stats = (Estadisticas) datos.get("estadisticas");
            estadisticas.incrementarVentas(stats.getTotalVendidas());
            estadisticas.agregarIngresos(stats.getIngresosTotales());
            estadisticas.incrementarReservasActivas(stats.getReservasActivas());
            estadisticas.incrementarReservasConvertidas(stats.getReservasConvertidas());
            estadisticas.incrementarBebidasRegaladas(stats.getBebidasRegaladas());
            
            debugLog("Datos cargados exitosamente:");
            debugLog("- Eventos: " + eventos.size());
            debugLog("- Clientes: " + clientes.size());
            debugLog("- Promociones: " + promociones.size());
            debugLog("- Transacciones: " + transacciones.size());
            debugLog("- Reservas activas: " + reservasActivas.size());
            debugLog("- Asientos reservados: " + reservasPorAsiento.size());
            
        } catch (IOException | ClassNotFoundException e) {
            debugLog("Error al cargar datos: " + e.getMessage());
            System.err.println("Error al cargar datos: " + e.getMessage());
        }
    }
    
    
    private void crearEvento() {
        debugLog("Creando nuevo evento...");
        
        // 1. Validación nombre (no vacío)
        String nombre;
        do {
            System.out.print("\nIngrese nombre del evento: ");
            nombre = scanner.nextLine().trim();
            if (nombre.isEmpty()) {
                System.out.println("❌ Error: El nombre no puede estar vacío");
            }
        } while (nombre.isEmpty());
        
        // 2. Validación fecha (formato + fecha futura)
        LocalDate fecha = null;
        while (fecha == null) {
            System.out.print("Ingrese fecha del evento (dd/MM/yyyy): ");
            String fechaStr = scanner.nextLine();
            
            try {
                fecha = LocalDate.parse(fechaStr, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            
                // Verificar que la fecha no sea pasada
                if (fecha.isBefore(LocalDate.now())) {
                    System.out.println("Error: La fecha debe ser futura");
                    fecha = null;
                }
            } catch (Exception e) {
                System.out.println("❌ Error: Formato inválido. Use dd/MM/yyyy (ej: 25/12/2024)");
            }
        }
        
         // 3. Creación del evento
        Evento nuevoEvento = new Evento(nombre, fecha);
        eventos.add(nuevoEvento);
        limpiarCacheEventos();
        
        // 4. Confirmación con detalles
        debugLog("Evento creado: " + nombre + " - Fecha: " + fecha.format(DateTimeFormatter.ISO_LOCAL_DATE));
        System.out.println("\n✅ Evento creado exitosamente:");
        System.out.println("   Nombre: " + nombre);
        System.out.println("   Fecha: " + fecha.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy")));
    }
    
    private void agregarFuncion() {
        debugLog("Agregando función a evento...");
        if (eventos.isEmpty()) {
            debugLog("No hay eventos registrados");
            System.out.println("No hay eventos registrados");
            return;
        }
    
        listarEventosPaginados();
        System.out.print("Seleccione evento al que agregará función: ");
        int opcionEvento = scanner.nextInt();
        scanner.nextLine();
        
        if (opcionEvento < 1 || opcionEvento > eventos.size()) {
            debugLog("Opción de evento inválida: " + opcionEvento);
            System.out.println("Opción inválida");
            return;
        }
        
        Evento evento = eventos.get(opcionEvento - 1);
        debugLog("Evento seleccionado: " + evento.getNombre());
        
        System.out.print("Ingrese fecha y hora de la función (dd/MM/yyyy HH:mm): ");
        String fechaHoraStr = scanner.nextLine();
        
        try {
            LocalDateTime fechaHora = LocalDateTime.parse(fechaHoraStr, 
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
            evento.agregarFuncion(new Funcion(fechaHora));
            limpiarCacheEventos();
            debugLog("Función agregada: " + fechaHora.format(DATE_FORMATTER));
            System.out.println("Función agregada exitosamente");
        } catch (Exception e) {
            debugLog("Error al agregar función: " + e.getMessage());
            System.out.println("Error al agregar función: " + e.getMessage());
        }
    }

    private int leerOpcion(int min, int max) {
        while (true) {
            try {
                System.out.print("Seleccione una opción: ");
                int opcion = Integer.parseInt(scanner.nextLine());
                if (opcion >= min && opcion <= max) {
                    debugLog("Opción seleccionada: " + opcion);
                    return opcion;
                }
                debugLog("Opción inválida: " + opcion);
                System.out.println("Opción inválida. Intente nuevamente.");
            } catch (NumberFormatException e) {
                debugLog("Entrada no numérica recibida");
                System.out.println("Debe ingresar un número válido.");
            }
        }
    }
    
    
    // 10 Métodos auxiliares (Validaciones, Cálculos, etc.)
    private boolean validarFormatoAsiento(String codigo) {
        if (codigo == null || codigo.isEmpty()) {
            return false;
        }
        
        codigo = codigo.trim().toUpperCase();
        
        // Verificar que empiece con V, P o G
        if (!codigo.matches("^[VPG].*")) {
            return false;
        }
        
        // Verificar que el número sea del 1 al 10
        try {
            int numero = Integer.parseInt(codigo.substring(1));
            return numero >= 1 && numero <= 10;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Mejora aplicada 11: Validación mejorada de email
    
    private boolean validarEmail(String email) {
        if (email == null || email.isEmpty()) {
            debugLog("Error: El email no puede estar vacío.");
            debugLog("Email es nulo o vacío");
            return false;
        }
        
        boolean valido = email.matches(EMAIL_REGEX);
        if (!valido) {
            System.out.println("❌ Error: El formato del email es inválido (ejemplo: usuario@dominio.com)."); //Validación de email
            debugLog("Formato de email inválido: " + email);
        }
        return valido;}

    private boolean confirmar(String mensaje) {
        System.out.print(mensaje + " (S/N): ");
        String respuesta = scanner.nextLine();
        boolean confirmado = respuesta.equalsIgnoreCase("S");
        debugLog("Confirmación '" + mensaje + "' respuesta: " + respuesta + " - Resultado: " + confirmado);
        return confirmado;
    }

    private Object[] calcularPrecioFinalConDescuento(Zona zona, Cliente cliente) {
        double precio = zona.getPrecio();
        double maxDescuento = 0.0;
        String tipoDescuento = "Ninguno";

            for (Promocion promo : promociones) {
                if (promo.aplica(cliente) && promo.getDescuento() > maxDescuento) {
                    maxDescuento = promo.getDescuento();
                    tipoDescuento = promo.getNombre();
                }
            }
            return new Object[]{precio * (1 - maxDescuento), maxDescuento, tipoDescuento};
    }
        
        
     
    private void aplicarPromociones(Transaccion transaccion) {
        if (transaccion.getEntradas().size() >= 2) {
            estadisticas.incrementarBebidasRegaladas(2);
            debugLog("Promoción aplicada: Grupo Familiar - 2 bebidas gratis");
            System.out.println("¡Promoción aplicada! 2 bebidas gratis");
        }
    }
    
    private void mostrarPlanoAsientos(Funcion funcion) {
        System.out.println("\n--- PLANO DE ASIENTOS ---");
        System.out.println("   1     2     3     4     5     6     7     8     9    10");
        
        
        for (Zona zona : Zona.values()) {
            System.out.printf("%s ($%.0f): ", zona.name(), zona.getPrecio());
            
            for (int i = 1; i <= ASIENTOS_POR_FILA; i++) {
                String codigo = "" + zona.name().charAt(0) + i; // Código como "V1", "P2", etc.
                Asiento asiento = funcion.getAsiento(codigo);
                System.out.print(asiento.getEstado().getSimbolo() + " ");
            }
            
            System.out.println();
        }
        
        System.out.println("\nLeyenda:");
        System.out.println(EstadoAsiento.DISPONIBLE.getSimbolo() + " Disponible  " + 
                      EstadoAsiento.RESERVADO.getSimbolo() + " Reservado  " + 
                      EstadoAsiento.VENDIDO.getSimbolo() + " Vendido");
    }
    
    private Cliente registrarCliente() {
        System.out.print("\nIngrese nombre del cliente: ");
        String nombre = scanner.nextLine().trim();
        
        // Validación nombre (no vacío)
        while (nombre.isEmpty()) {
            System.out.println("Error: El nombre no puede estar vacío");
            System.out.print("Ingrese nombre del cliente: ");
            nombre = scanner.nextLine().trim();
        }
        
        //Validación de género (M: Masculino/F: Femenino)
        char genero;
        while (true){
            System.out.println("Ingrese su genero (M (Masculino)/F (Femenino)");
            String inputGenero = scanner.nextLine().trim().toUpperCase();
            
            if (inputGenero.equals("M")|| inputGenero.equals("F")) { //Validar que datos ingresados sean correctos
                genero = inputGenero.charAt(0);
                break;
                 } else {
                System.out.println("Error: Por favor ingrese 'M' para Masculino o 'F' para Femenino.");
            }
        }
        
        //Validación de Estudiante
        boolean estudiante;
        while (true){
            System.out.println("Es estudiante? (S/N)");
            String inputestudiante = scanner.nextLine().trim().toUpperCase();
            
            if (inputestudiante.equals("S")){
                estudiante = true;
                break;
            } else if (inputestudiante.equals("N")){
                estudiante = false;
                break;
            } else {
                System.out.println("Error: Por favor ingrese 'S' para Si y 'N' para No");
            }
        }


        
        // Validación edad (entre 5 y 110 años)
        int edad = -1;
        final int EDAD_MINIMA = 5;
        final int EDAD_MAXIMA = 110;
        
        while (true) {
            System.out.print("\nIngrese edad del cliente (" + EDAD_MINIMA + "-" + EDAD_MAXIMA + " años): ");
            String input = scanner.nextLine().trim();
            
            try {
                edad = Integer.parseInt(input);
                
                if (edad < EDAD_MINIMA) {
                    System.out.println("❌ Error: La edad mínima es " + EDAD_MINIMA + " años");
                } else if (edad > EDAD_MAXIMA) {
                    System.out.println("❌ Error: La edad máxima es " + EDAD_MAXIMA + " años");
                } else {
                    break; // Edad válida, salir del bucle
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Error: Debe ingresar un número entero válido");
            }
        }
        
        
        // Validación email (formato básico + no duplicado)
        String email;
        boolean emailValido;
        do {
            System.out.print("Ingrese email del cliente: ");
            email = scanner.nextLine().trim();
            emailValido = validarEmail(email);
            
            if (!emailValido) {
                System.out.println("Error: Email inválido (ejemplo: usuario@dominio.com)");
            } else if (emailExistente(email)) {
                System.out.println("Error: Este email ya está registrado");
                emailValido = false;
            }
        } while (!emailValido);
        
        // Crear y retornar cliente
        Cliente cliente = new Cliente(clientes.size() + 1, nombre, edad, email,genero,estudiante);
        clientes.add(cliente);
        System.out.println("Cliente registrado exitosamente!");
        return cliente;
    }
    
    // Método auxiliar para evitar duplicados
    boolean emailExistente(String email) {
        for (Cliente c : clientes) {
            if (c.getEmail().equalsIgnoreCase(email)) {
                return true;
            }
        }
        return false;
    }
    

    private int leerEnteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                int valor = Integer.parseInt(scanner.nextLine());
                debugLog("Entrada recibida: " + valor);
                return valor;
            } catch (NumberFormatException e) {
                debugLog("Entrada no numérica recibida");
                System.out.println("Debe ingresar un número válido");
            }
        }
    }

    private void actualizarEstadisticas(Transaccion transaccion) {
        debugLog("Actualizando estadísticas con transacción ID: " + transaccion.getId());
        estadisticas.incrementarVentas(transaccion.getEntradas().size());
        estadisticas.agregarIngresos(transaccion.getTotal());
        debugLog("Estadísticas actualizadas - Ventas totales: " + estadisticas.getTotalVendidas() + 
                " - Ingresos totales: " + estadisticas.getIngresosTotales());
    }

    private void imprimirBoleta(Transaccion transaccion) {
        debugLog("Generando boleta para transacción ID: " + transaccion.getId());
        System.out.println("\n=== BOLETA ELECTRÓNICA ===");
        System.out.println("Teatro: " + NOMBRE_TEATRO);
        System.out.println("N° Transacción: " + transaccion.getId());
        System.out.println("Cliente: " + transaccion.getCliente().getNombre());
        System.out.println("Fecha: " + transaccion.getFecha().format(DATE_FORMATTER));
        
        System.out.println("\nDetalle:");
        System.out.println("--------------------------------------------------");
        System.out.printf("%-8s %-10s %-15s %-15s %-15s %-20s\n", "Asiento", "Zona", "Precio Original", "Descuento (%)", "Precio Final", "Tipo de Descuento");
        System.out.println("--------------------------------------------------");
        
        for (Entrada entrada : transaccion.getEntradas()) {
            System.out.printf("%-8s %-10s $%-14.2f %-14.2f $%-14.2f %-20s\n", 
                entrada.getCodigoAsiento(), 
                entrada.getZona().getNombre(),
                entrada.getPrecioOriginal(),
                entrada.getDescuentoAplicado() * 100,
                entrada.getprecioFinal(),
                entrada.getTipoDescuento());
        }
        
        double total = transaccion.getEntradas().stream().mapToDouble(Entrada::getprecioFinal).sum();
        System.out.println("--------------------------------------------------");
        System.out.printf("%-58s $%-9.2f\n", "TOTAL:", transaccion.getTotal());
        System.out.println("==================================================");
    }

    private void gestionarReservas() {
        debugLog("Accediendo a gestión de reservas");
        System.out.println("\n--- GESTIÓN DE RESERVAS ---");
        System.out.println("1. Convertir reserva a compra");
        System.out.println("2. Liberar reservas expiradas manualmente");
        System.out.println("3. Listar reservas activas");
        System.out.println("4. Volver");
        
        int opcion = leerOpcion(1, 4);
        
        switch (opcion) {
            case 1 -> convertirReserva();
            case 2 -> liberarReservasExpiradasOptimizado();
            case 3 -> listarReservasActivas();
        }
    }

    // Mejora aplicada 12: Conversión optimizada de reservas usando mapa
    private void convertirReserva() {
        debugLog("Convirtiendo reserva a compra...");
        System.out.print("\nIngrese código de asiento reservado: ");
        String codigo = scanner.nextLine().toUpperCase();
        debugLog("Buscando reserva para asiento: " + codigo);
        
        Transaccion t = reservasPorAsiento.get(codigo);
        if (t != null) {
            debugLog("Reserva encontrada ID: " + t.getId() + " - Cliente: " + t.getCliente().getNombre());
            
            for (Entrada e : t.getEntradas()) {
                if (e.getCodigoAsiento().equals(codigo)) {
                    e.setEstado("Comprado");
                    reservasPorAsiento.remove(codigo);
                }
            }
            
            t.setEstado("Completada");
            reservasActivas.remove(t);
            
            estadisticas.incrementarReservasConvertidas(1);
            estadisticas.incrementarVentas(1);
            estadisticas.agregarIngresos(t.getTotal());
            
            debugLog("Reserva convertida exitosamente. Asiento: " + codigo);
            System.out.println("Reserva convertida a compra exitosamente");
            return;
        }
        
        debugLog("No se encontró reserva para asiento: " + codigo);
        System.out.println("No se encontró reserva activa para el asiento " + codigo);
    }

    private void listarReservasActivas() {
        debugLog("Listando reservas activas");
        if (reservasActivas.isEmpty()) {
            debugLog("No hay reservas activas");
            System.out.println("No hay reservas activas");
            return;
        }
        
        System.out.println("\nReservas Activas:");
        for (Transaccion t : reservasActivas) {
            System.out.printf("Transacción %d - Cliente: %s - %s\n",
                t.getId(), t.getCliente().getNombre(), t.getFechaReserva().format(DATE_FORMATTER));
            
            System.out.println("  Asientos reservados:");
            for (Entrada e : t.getEntradas()) {
                System.out.printf("  - %s (%s) $%.2f\n",
                    e.getCodigoAsiento(), e.getZona().getNombre(), e.getprecioFinal());
            }
        }
        debugLog("Total reservas activas listadas: " + reservasActivas.size());
    }

    private void mostrarReportes() {
        debugLog("Accediendo a reportes y estadísticas");
        System.out.println("\n--- REPORTES Y ESTADÍSTICAS ---");
        System.out.println("1. Ventas por evento");
        System.out.println("2. Ocupación por función");
        System.out.println("3. Estadísticas generales");
        System.out.println("4. Volver");
        
        int opcion = leerOpcion(1, 4);
        
        switch (opcion) {
            case 1 -> generarReporteVentas();
            case 2 -> generarReporteOcupacion();
            case 3 -> mostrarEstadisticas();
        }
    }

    private void generarReporteVentas() {
        debugLog("Generando reporte de ventas...");
        if (transacciones.isEmpty()) {
            debugLog("No hay transacciones para generar reporte");
            System.out.println("No hay ventas registradas");
            return;
        }
        
        System.out.println("\n=== REPORTE DE VENTAS ===");
        
        Map<String, Double> ventasPorZona = new HashMap<>();
        Map<String, Integer> entradasPorZona = new HashMap<>();
        
        for (Transaccion t : transacciones) {
            if (t.getEstado().equals("Completada")) {
                for (Entrada e : t.getEntradas()) {
                    String zona = e.getZona().getNombre();
                    ventasPorZona.put(zona, ventasPorZona.getOrDefault(zona, 0.0) + e.getprecioFinal());
                    entradasPorZona.put(zona, entradasPorZona.getOrDefault(zona, 0) + 1);
                }
            }
        }
        
        for (String zona : ventasPorZona.keySet()) {
            System.out.printf("\nZona: %s\n", zona);
            System.out.printf("Total entradas vendidas: %d\n", entradasPorZona.get(zona));
            System.out.printf("Ingresos totales: $%.2f\n", ventasPorZona.get(zona));
        }
        debugLog("Reporte de ventas generado para " + ventasPorZona.size() + " zonas");
    }

    private void generarReporteOcupacion() {
        debugLog("Generando reporte de ocupación...");
        if (eventos.isEmpty()) {
            debugLog("No hay eventos para generar reporte");
            System.out.println("No hay eventos registrados");
            return;
        }
        
        System.out.println("\n=== REPORTE DE OCUPACIÓN ===");
        
        for (Evento evento : eventos) {
            System.out.println("\nEvento: " + evento.getNombre());
            
            for (Funcion funcion : evento.getFunciones()) {
                System.out.println("\nFunción: " + funcion.getFechaHora().format(DATE_FORMATTER));
                
                int totalAsientos = funcion.getAsientos().size();
                int asientosOcupados = 0;
                
                for (Asiento asiento : funcion.getAsientos().values()) {
                    if (asiento.estaVendido() || asiento.estaReservado()) {
                        asientosOcupados++;
                    }
                }
                
                double porcentajeOcupacion = (double) asientosOcupados / totalAsientos * 100;
                
                System.out.printf("Asientos ocupados: %d/%d (%.2f%%)\n",
                    asientosOcupados, totalAsientos, porcentajeOcupacion);
            }
        }
        debugLog("Reporte de ocupación generado para " + eventos.size() + " eventos");
    }

    // Mostrar estadisticas
    private void mostrarEstadisticas() {
        debugLog("Mostrando estadísticas generales");
        System.out.println("\n=== ESTADÍSTICAS GENERALES ===");
        System.out.println("Total entradas vendidas: " + estadisticas.getTotalVendidas());
        System.out.printf("Ingresos totales: $%.2f\n", estadisticas.getIngresosTotales());
        System.out.println("Reservas activas: " + estadisticas.getReservasActivas());
        System.out.println("Reservas convertidas: " + estadisticas.getReservasConvertidas());
        System.out.println("Bebidas regaladas: " + estadisticas.getBebidasRegaladas());
    }

    // Administrar sistema
    private void administrarSistema() {
        debugLog("Accediendo a administración del sistema");
        System.out.println("\n--- ADMINISTRACIÓN DEL SISTEMA ---");
        System.out.println("1. Gestionar promociones");
        System.out.println("2. Respaldar datos");
        System.out.println("3. Restaurar datos");
        System.out.println("4. Volver");
        
        int opcion = leerOpcion(1, 4);
        
        switch (opcion) {
            case 1 -> gestionarPromociones();
            case 2 -> respaldarDatos();
            case 3 -> restaurarDatos();
        }
    }

    // Gestionar promociones
    private void gestionarPromociones() {
        debugLog("Accediendo a gestión de promociones");
        System.out.println("\n--- GESTIÓN DE PROMOCIONES ---");
        System.out.println("1. Agregar promoción");
        System.out.println("2. Listar promociones");
        System.out.println("3. Eliminar promoción");
        System.out.println("4. Volver");
        
        int opcion = leerOpcion(1, 4);
        
        switch (opcion) {
            case 1 -> agregarPromocion();
            case 2 -> listarPromociones();
            case 3 -> eliminarPromocion();
        }
    }

    // Agregar promocion
    private void agregarPromocion() {
        debugLog("Agregando nueva promoción");
        System.out.print("\nIngrese nombre de la promoción: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Ingrese descripción: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Ingrese descuento (ej: 0.15 para 15%): ");
        double descuento = Double.parseDouble(scanner.nextLine());
        
        System.out.println("Seleccione criterio:");
        System.out.println("1. Para estudiantes (menores de 25)");
        System.out.println("2. Para tercera edad (65+)");
        System.out.println("3. Para todos");
        
        int criterio = leerOpcion(1, 3);
        Predicate<Cliente> predicado = switch (criterio) {
            case 1 -> Cliente::esEstudiante;
            case 2 -> Cliente::esTerceraEdad;
            default -> c -> true;
        };
        
        promociones.add(new Promocion(nombre, descripcion, descuento, predicado));
        debugLog("Promoción agregada: " + nombre + " - Descuento: " + (descuento*100) + "%");
        System.out.println("Promoción agregada exitosamente");
    }

    private void listarPromociones() {
        debugLog("Listando promociones");
        if (promociones.isEmpty()) {
            debugLog("No hay promociones registradas");
            System.out.println("No hay promociones registradas");
            return;
        }
        
        System.out.println("\nListado de Promociones:");
        for (int i = 0; i < promociones.size(); i++) {
            Promocion p = promociones.get(i);
            System.out.printf("%d. %s - %s (%.0f%% descuento)\n", 
                i+1, p.getNombre(), p.getDescripcion(), p.getDescuento() * 100);
        }
        debugLog("Total promociones listadas: " + promociones.size());
    }

    private void eliminarPromocion() {
        debugLog("Eliminando promoción");
        listarPromociones();
        if (promociones.isEmpty()) {
            debugLog("No hay promociones para eliminar");
            return;
        }
        
        System.out.print("\nSeleccione promoción a eliminar: ");
        int opcion = leerOpcion(1, promociones.size());
        
        Promocion eliminada = promociones.remove(opcion-1);
        debugLog("Promoción eliminada: " + eliminada.getNombre());
        System.out.println("Promoción eliminada exitosamente");
    }

    private void respaldarDatos() {
        debugLog("Respaldando datos del sistema");
        guardarDatos();
        System.out.println("Datos respaldados exitosamente");
    }

    private void restaurarDatos() {
        debugLog("Restaurando datos del sistema");
        cargarDatos();
        System.out.println("Datos restaurados exitosamente");
    }
}