/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exp2_s6_cristian_olivares;

/**
 *
 * @author Cristian Olivares Sandia
 */


import java.util.ArrayList;
import java.util.Scanner;

public class Exp2_S6_Cristian_Olivares {
    //Paso 1: Declaración de varaibles
    // A: Constantes para estados de asientos (reservado, disponible, vendido)
    private static final String ASIENTO_DISPONIBLE = "[ ]";
    private static final String ASIENTO_RESERVADO = "[R]";
    private static final String ASIENTO_VENDIDO = "[X]";
    
    // B: Variables estáticas para estadísticas globales
    static int totalVendidas = 0;
    static double ingresosTotales = 0;
    static int reservasTotales = 0;
    static int reservasConvertidas = 0;
    static int bebidasRegaladas = 0;
    static long ultimoNumeroTransaccion = 1;

    // C: Precios de las zonas
    static final double PRECIO_VIP = 20000;
    static final double PRECIO_PLATEA = 15000;
    static final double PRECIO_GENERAL = 10000;

    // D: Variables de instancia
    static String[][] asientos = new String[3][10];
    static ArrayList<Entrada> ventas = new ArrayList<>();
    static final String nombreTeatro = "Teatro Moro";
    static final int TIEMPO_RESERVA_MINUTOS = 30;

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        inicializarSistema();
        mostrarMenuPrincipal();
    }

    // Paso 2: Menú del programa del Teatro
    private static void inicializarSistema() {
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                asientos[i][j] = ASIENTO_DISPONIBLE;
            }
        }
        System.out.println("Bienvenidos al Teatro Moro");
    }

    // A: Menú principal interactivo
    private static void mostrarMenuPrincipal() {
        int opcion;
        do {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Reservar entradas"); // reserva de entradas
            System.out.println("2. Comprar entradas"); // compra directa de entradas
            System.out.println("3. Convertir reserva a compra"); //comprar boleto reservado
            System.out.println("4. Modificar una venta"); // modificar datos
            System.out.println("5. Imprimir boleta"); // imprimir la boleta con datos
            System.out.println("6. Mostrar estadisticas"); // mostrar estadisticas de ventas
            System.out.println("7. Ver ofertas especiales"); // mostrar ofertas disponibles del teatro
            System.out.println("8. Salir");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.println("[DEBUG] Menú: Reservar entradas");
                    realizarReserva();
                }
                case 2 -> {
                    System.out.println("[DEBUG] Menú: Comprar entradas");
                    realizarCompra();
                }
                case 3 -> convertirReserva();
                case 4 -> modificarVenta();
                case 5 -> imprimirBoleta();
                case 6 -> mostrarEstadisticas();
                case 7 -> mostrarOfertas();
                case 8 -> System.out.println("Gracias por usar el sistema del Teatro Moro.");
                default -> System.out.println("Opcion no valida. Intente de nuevo.");
            }
        } while (opcion != 8);
    }

    //B: Ofertas disponibles
    private static void mostrarOfertas() {
        System.out.println("\n=== OFERTAS ESPECIALES ===");
        System.out.println("1. Descuento del 10% para estudiantes (menores de 25 años)");
        System.out.println("2. Descuento del 15% para personas de la tercera edad (65+ años)");
        System.out.println("3. Promocion especial: Por la compra de 2 entradas");
        System.out.println("   - 2 bebidas gratis");
        System.out.println("   - Aplicable a todas las zonas (VIP, Platea, General)");
        System.out.println("\nEstas ofertas se aplican automáticamente al realizar tu compra.");
    }

    
    //Paso 3: Manejo de las entradas
    // A: Realizar una reserva
    
    private static void realizarReserva() {
        ultimoNumeroTransaccion++;
        System.out.println("\n--- RESERVAR ENTRADAS ---");
        mostrarPlanoAsientosConPrecios();
        
        System.out.print("Ingrese el asiento a reservar (Ej: A1 VIP): ");
        String input = scanner.nextLine().toUpperCase().trim();
        
        System.out.println("[DEBUG] Input recibido: '" + input + "'");

        String[] partes = input.split(" ");
        if (partes.length < 2) {
            System.out.println("Formato incorrecto. Debe ser: LetraNumero Zona (Ej: A1 VIP)");
            return;
        }

        String asiento = partes[0];
        String tipoZona = partes[1];
        
        System.out.println("[DEBUG] Asiento: " + asiento + " | Zona: " + tipoZona);

        if (!tipoZona.equalsIgnoreCase("VIP") && !tipoZona.equalsIgnoreCase("PLATEA") && !tipoZona.equalsIgnoreCase("GENERAL")) {
            System.out.println("Zona no valida. Use VIP, Platea o General.");
            return;
        }

        double precioBase = obtenerPrecioZona(tipoZona);
        
        System.out.println("[DEBUG] Precio base para zona " + tipoZona + ": $" + precioBase);

        if (!validarFormatoAsiento(asiento)) {
            System.out.println("Error: Formato de asiento incorrecto.");
            return;
        }

        if (!validarAsientoDisponible(asiento)) {
            System.out.println("Error: El asiento no esta disponible.");
            int filaDebug = obtenerFila(asiento);
            int columnaDebug = obtenerColumna(asiento);
            if (filaDebug != -1 && columnaDebug != -1) {
                System.out.println("[DEBUG] Estado actual del asiento " + asiento + ": " + asientos[filaDebug][columnaDebug]);
            }
            return;
        }

        int fila = obtenerFila(asiento);
        int columna = obtenerColumna(asiento);

        if (fila == -1 || columna == -1) {
            System.out.println("Error: Asiento no valido.");
            return;
        }
        
        System.out.println("[DEBUG] Estado PRE-reserva del asiento " + asiento + ": " + asientos[fila][columna]);

        asientos[fila][columna] = ASIENTO_RESERVADO;
        reservasTotales++;
        long timestamp = System.currentTimeMillis();
        ventas.add(new Entrada(asiento, "Reservado", precioBase, timestamp, tipoZona, ultimoNumeroTransaccion));
        
        System.out.println("[DEBUG] Reserva exitosa:");
        System.out.println("[DEBUG] - Asiento: " + asiento);
        System.out.println("[DEBUG] - Estado POST-reserva: " + asientos[fila][columna]);
        System.out.println("[DEBUG] - Tiempo de reserva iniciado: " + new java.util.Date(timestamp));
        System.out.println("[DEBUG] - N° Transacción: " + ultimoNumeroTransaccion);
        System.out.println("Reserva exitosa: Asiento " + asiento + " (" + tipoZona + ") reservado por " + 
                     TIEMPO_RESERVA_MINUTOS + " minutos. Precio base: $" + precioBase);
    }

    //B: Realizar compra
    private static void realizarCompra() {
        System.out.println("\n--- COMPRAR ENTRADAS ---");
        mostrarPlanoAsientosConPrecios();
        System.out.print("¿Desea comprar (1) asientos disponibles o (2) convertir una reserva? [1/2]: ");
        int tipoCompra = leerEntero();
        scanner.nextLine();

        if (tipoCompra == 1) {
            comprarAsientosDisponibles();
        } else if (tipoCompra == 2) {
            convertirReserva();
        } else {
            System.out.println("Opcion no valida.");
        }
    }
    
    //C: Asientos disponibles
    private static void comprarAsientosDisponibles() {
        System.out.print("¿Cuantas entradas desea comprar? (1-10): ");
        int cantidad = leerEntero();
        scanner.nextLine();

        if (cantidad < 1 || cantidad > 10) {
            System.out.println("Cantidad no valida. Debe ser entre 1 y 10.");
            return;
        }
        
        int disponibles = contarAsientosDisponibles();
        if (cantidad > disponibles) {
            System.out.println("Error: Solo quedan " + disponibles + " asientos disponibles");
            return;
        }
        
        ultimoNumeroTransaccion++;
        long numeroTransaccionActual = ultimoNumeroTransaccion;

        if (cantidad >= 2) {
            System.out.println("\n¡Promocion especial! Por comprar " + cantidad + " entradas, llevas 2 bebidas gratis.");
            bebidasRegaladas += 2;
        }

        for (int i = 0; i < cantidad; i++) {
            boolean compraExitosa = false;
            while (!compraExitosa) {
                System.out.print("\nIngrese el asiento #" + (i + 1) + " a comprar (Ej: A1 VIP): ");
                String input = scanner.nextLine().toUpperCase().trim();
                
                String[] partes = input.split(" ");
                if (partes.length < 2) {
                    System.out.println("Formato incorrecto. Debe ser: LetraNumero Zona (Ej: A1 VIP)");
                    continue;
                }
                
                String asiento = partes[0];
                String tipoZona = partes[1];

                if (!tipoZona.equalsIgnoreCase("VIP") && !tipoZona.equalsIgnoreCase("PLATEA") && !tipoZona.equalsIgnoreCase("GENERAL")) {
                    System.out.println("Zona no valida. Use VIP, Platea o General.");
                    continue;
                }

                double precioBase = obtenerPrecioZona(tipoZona);

                if (!validarFormatoAsiento(asiento)) {
                    System.out.println("Formato de asiento incorrecto. Ejemplos: A1, B2, C10");
                    continue;
                }

                if (!validarAsientoDisponible(asiento)) {
                    System.out.println("El asiento no esta disponible para compra directa.");
                    continue;
                }

                System.out.print("Ingrese la edad del comprador: ");
                int edad = leerEnteroPositivo(); // para evitar que pongan un numero negativo
                scanner.nextLine();

                double precioFinal = calcularPrecioConDescuento(edad, precioBase);
                int fila = obtenerFila(asiento);
                int columna = obtenerColumna(asiento);

                if (fila == -1 || columna == -1) {
                    System.out.println("Error: Asiento no valido. Intente nuevamente.");
                    continue;
                }

                asientos[fila][columna] = ASIENTO_VENDIDO;
                totalVendidas++;
                ingresosTotales += precioFinal;
                ventas.add(new Entrada(asiento, "Comprado", precioFinal, System.currentTimeMillis(), tipoZona, numeroTransaccionActual));
                
                System.out.println("¡Compra exitosa! Asiento " + asiento + " - Número de transacción: " + numeroTransaccionActual);
                System.out.println("Puede usar este número para imprimir todas sus boletas más tarde.");
                if (edad < 25) {
                    System.out.println("Descuento (Estudiante <25 años): 10%");
                } else if (edad >= 65) {
                    System.out.println("Descuento (Tercera edad 65+ años): 15%");
                }
                System.out.println("Precio final: $" + precioFinal);
                
                compraExitosa = true;
            }
        }
        
        if (cantidad >= 2) {
            System.out.println("\n¡Recuerda tu promoción! Tienes 2 bebidas gratis por tu compra.");
        }
    }
      
    // D: Convertir reserva a compra
    private static void convertirReserva() {
        System.out.println("\n[DEBUG] Iniciando conversión de reserva");
        System.out.println("\n--- CONVERTIR RESERVA A COMPRA ---");
        System.out.print("Ingrese el asiento reservado a comprar (Ej: A1 VIP): ");
        String input = scanner.nextLine().toUpperCase().trim();

        String[] partes = input.split(" ");
        if (partes.length < 2) {
            System.out.println("Formato incorrecto. Debe ser: LetraNúmero Zona (Ej: A1 VIP)");
            return;
        }

        String asiento = partes[0];
        Entrada reserva = buscarReserva(asiento);
        if (reserva == null) {
            System.out.println("No se encontró una reserva activa para el asiento " + asiento);
            return;
        }
        
        ultimoNumeroTransaccion++;
        reserva.numeroTransaccion = ultimoNumeroTransaccion;

        long tiempoTranscurrido = (System.currentTimeMillis() - reserva.timestamp) / (60 * 1000);
        long segundos = ((System.currentTimeMillis() - reserva.timestamp) % (60 * 1000)) / 1000;
        
        if (tiempoTranscurrido > TIEMPO_RESERVA_MINUTOS) {
            System.out.printf("La reserva ha expirado (%d minutos %d segundos).\n",tiempoTranscurrido, segundos);
            reservasTotales--;
            liberarAsiento(asiento);
            return;
        }

        System.out.print("Ingrese la edad del comprador: ");
        int edad = leerEnteroPositivo(); // para evitar una edad negativa
        scanner.nextLine();

        double precioFinal = calcularPrecioConDescuento(edad, reserva.precio);
        int fila = obtenerFila(asiento);
        int columna = obtenerColumna(asiento);

        if (fila == -1 || columna == -1) {
            System.out.println("Error: Asiento no válido.");
            return;
        }

        asientos[fila][columna] = ASIENTO_VENDIDO;
        reserva.estado = "Comprado";
        reserva.precio = precioFinal;
        totalVendidas++;
        reservasConvertidas++;
        ingresosTotales += precioFinal;
        
        System.out.println("\n¡Reserva convertida a compra exitosamente!");
        System.out.println("Asiento: " + reserva.asiento + " (" + reserva.zona + ")");
        System.out.println("Precio base: $" + reserva.precio);
        if (edad < 25) {
            System.out.println("Descuento (Estudiante <25 años): 10%");
        } else if (edad >= 65) {
            System.out.println("Descuento (Tercera edad 65+ años): 15%");
        }
        System.out.println("Precio final: $" + precioFinal);
        System.out.println("Número de transacción: " + reserva.numeroTransaccion);
    }

    // E: Modificar venta
    private static void modificarVenta() {
        System.out.println("\n--- MODIFICAR VENTA ---");
        System.out.print("Ingrese el asiento a modificar (Ej: A1 VIP): ");
        String input = scanner.nextLine().toUpperCase().trim();

        String[] partes = input.split(" ");
        if (partes.length < 1) {
            System.out.println("Formato incorrecto. Debe incluir el asiento.");
            return;
        }

        String asiento = partes[0];
        Entrada entrada = buscarEntrada(asiento);
        if (entrada == null) {
            System.out.println("No se encontró ninguna venta/reserva para el asiento " + asiento);
            return;
        }

        System.out.println("Datos actuales: " + entrada);
        System.out.print("¿Qué desea modificar? (1) Estado, (2) Precio [1/2]: ");
        int opcion = leerEntero();
        scanner.nextLine();

        switch (opcion) {
            case 1 -> {
                System.out.print("Nuevo estado (Reservado/Comprado/Cancelado): ");
                String nuevoEstado = scanner.nextLine();
                
                if (!validarEstado(nuevoEstado)) {
                    System.out.println("Estado no válido.");
                    return;
                }
                
                int fila = obtenerFila(asiento);
                int columna = obtenerColumna(asiento);
                if (nuevoEstado.equalsIgnoreCase("Comprado") && !asientos[fila][columna].equals(ASIENTO_VENDIDO)) {
                    System.out.println("Error: El asiento debe estar vendido para este estado");
                    return;
                }
                entrada.estado = nuevoEstado;
                System.out.println("Estado actualizado correctamente.");
            }
            case 2 -> {
                System.out.print("Nuevo precio: ");
                double nuevoPrecio = leerDouble();
                scanner.nextLine();
                entrada.precio = nuevoPrecio;
                System.out.println("Precio actualizado correctamente.");
            }
            default -> System.out.println("Opción no válida.");
        }
    }
    
    // F: Imprimir boleta de compra
    private static void imprimirBoleta() {
        System.out.println("\n[DEBUG] Menú de impresión de boletas");
        System.out.println("\n--- IMPRIMIR BOLETA ---");
        System.out.println("1. Buscar por asiento individual");
        System.out.println("2. Buscar por número de transacción");
        System.out.print("Seleccione opción: ");
        
        int opcion = leerEntero();
        scanner.nextLine();
        
        switch(opcion) {
            case 1 -> {
                System.out.println("[DEBUG] Opción: Boleta individual");
                imprimirBoletaIndividual();
            }
            case 2 -> {
                System.out.println("[DEBUG] Opción: Boletas por transacción");
                imprimirBoletasPorTransaccion();
            }
            default -> System.out.println("Opción no válida");
        }
    }

    //G: Imprimir boletas multiples
    private static void imprimirBoletasPorTransaccion() {
        System.out.print("Ingrese su número de transacción: ");
        long numTransaccion = leerEntero();
        scanner.nextLine();
        
        if (numTransaccion <= 0) {
            System.out.println("Error: El número de transacción debe ser positivo");
            System.out.println("[DEBUG] Número de transacción inválido: " + numTransaccion);
            return;
        }
        
        System.out.println("\n=== BOLETAS DE LA TRANSACCIÓN " + numTransaccion + " ===");
        boolean encontradas = false;
        double totalTransaccion = 0;
        int contador = 0;
        
        for (Entrada entrada : ventas) {
            if (entrada.numeroTransaccion == numTransaccion) {
                contador++;
                System.out.println("\nBOLETA #" + contador);
                imprimirDetallesBoleta(entrada);
                totalTransaccion += entrada.precio;
                encontradas = true;
            }
        }
        
        if (encontradas) {
            System.out.println("-----------------------------");
            System.out.printf("TOTAL TRANSACCIÓN: $%.2f\n", totalTransaccion);
            System.out.println("=============================");
        } else {
            System.out.println("[DEBUG] No se encontraron boletas para la transacción: " + numTransaccion);
            System.out.println("No se encontraron boletas con ese número de transacción.");
        }
    }


    // H: Imprimir boleta individual
    private static void imprimirBoletaIndividual() {
        System.out.print("Ingrese el asiento para generar boleta (Ej: A1): ");
        String input = scanner.nextLine().toUpperCase().trim();

        if (input == null || input.isEmpty()) {
            System.out.println("Error: Debe ingresar un asiento");
            System.out.println("[DEBUG] Input vacío");
            return;
        }
        
        String[] partes = input.split(" ");
        String asiento = partes[0];
        
        Entrada entrada = buscarEntrada(asiento);
        
        if (entrada == null) {
            System.out.println("Error: No existe boleta para el asiento " + asiento);
            System.out.println("[DEBUG] Asiento no encontrado: " + asiento);
            return;
        }
        imprimirDetallesBoleta(entrada);
    }
    
    //I: Imprimir detalles de boleta
    private static void imprimirDetallesBoleta(Entrada entrada) {
        if (entrada == null) {
            System.out.println("No se encontró información para el asiento especificado");
            return;
        }

        java.util.Date fechaHora = new java.util.Date(entrada.timestamp);
        java.text.SimpleDateFormat formateador = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        
        System.out.println("\n=== BOLETA ELECTRÓNICA ===");
        System.out.println("Teatro: " + nombreTeatro);
        System.out.println("N° Transacción: " + entrada.numeroTransaccion);
        System.out.println("Asiento: " + entrada.asiento + " (" + entrada.zona + ")");
        System.out.println("Estado: " + entrada.estado);
        System.out.printf("Precio: $%.2f\n", entrada.precio);
        System.out.println("Fecha y hora de compra: " + formateador.format(fechaHora));
        
        if (entrada.estado.equals("Comprado") && entrada.precio < obtenerPrecioZona(entrada.zona)) {
            System.out.println("(Incluye descuento especial)");
        }
        System.out.println("=== GRACIAS POR SU COMPRA ===");
    }

    //J: Mostrar estadisticas de ventas
    private static void mostrarEstadisticas() {
        int totalAsientos = asientos.length * asientos[0].length;
        System.out.println("\n=== ESTADÍSTICAS DEL TEATRO ===");
        System.out.println("Total de entradas vendidas: " + totalVendidas);
        System.out.printf("Total de ingresos: $%.2f\n", ingresosTotales);
        System.out.println("Total de reservas activas: " + (reservasTotales - reservasConvertidas));
        System.out.println("Reservas convertidas a ventas: " + reservasConvertidas);
        System.out.println("Bebidas regaladas: " + bebidasRegaladas);
        
        
        int asientosOcupados = 0;
        for (String[] fila : asientos) {
            for (String estado : fila) {
                if (!estado.equals(ASIENTO_DISPONIBLE)) {
                    asientosOcupados++;
                }
            }
        }
        double ocupacion = (double) asientosOcupados / totalAsientos * 100;
        System.out.printf("Porcentaje de ocupación: %.2f%%\n", ocupacion);
    }

    // Paso 4: Funciones auxiliares 
    private static double obtenerPrecioZona(String zona) {
        if (!validarZona(zona)) {
            System.out.println("[DEBUG] Zona no válida: " + zona);
            return 0;
        }
        return switch (zona.toUpperCase()) {
            case "VIP" -> PRECIO_VIP;
            case "PLATEA" -> PRECIO_PLATEA;
            case "GENERAL" -> PRECIO_GENERAL;
            default -> 0;
        };
    }

    // A: Validar formato de asiento (A1, A2, etc)
    private static boolean validarFormatoAsiento(String asiento) {
        if (asiento == null || !asiento.matches("^[A-C](10|[1-9])$")) {
            System.out.println("\n❌ Error: Formato debe ser LetraNúmero (ej: A1, B10)");
            System.out.println("   - Letras válidas: A, B, C");
            System.out.println("   - Números válidos: 1 al 10");
            return false;
        }
        return true;
    }

    // B: Validar asiento disponible 
    private static boolean validarAsientoDisponible(String asiento) {
        
        if (!validarInputAsiento(asiento)) {
            System.out.println("[DEBUG] Input de asiento inválido");
            return false;
        }
        int fila = obtenerFila(asiento);
        int columna = obtenerColumna(asiento);
        
        if (fila == -1 || columna == -1) {
            System.out.println("Error: Asiento no existe. Use formato LetraNúmero (ej: A1)");
            return false;
        }
        try {
        String estado = asientos[fila][columna];
        System.out.println("[DEBUG] Estado actual: " + estado);
        return estado.equals(ASIENTO_DISPONIBLE);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("[DEBUG] Error: Asiento fuera de rango");
            return false;
        }
    }
    

    // C: Obtener fila  A-C
    private static int obtenerFila(String asiento) {
        if (asiento == null || asiento.isEmpty()) return -1;
        char fila = asiento.charAt(0);
        return fila >= 'A' && fila <= 'C' ? fila - 'A' : -1;
    }

    // D: Obtener columna 0-10
    private static int obtenerColumna(String asiento) {
        try {
            int columna = Integer.parseInt(asiento.substring(1)) - 1;
            return columna >= 0 && columna < 10 ? columna : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    //E: Calcular precio con descuento (estudiante y tercera edad)
    private static double calcularPrecioConDescuento(int edad, double precioBase) {
        System.out.println("[DEBUG] Aplicando descuento para edad: " + edad);
        if (edad < 0) {
            System.out.println("[ERROR] Edad no puede ser negativa");
            return precioBase;
        }
        if (edad <= 25){
            System.out.println("[DEBUG] Aplicando descuento del 10% (estudiante)");
            return precioBase * 0.90;
        }
        
        if (edad >= 65){
            System.out.println("[DEBUG] Aplicando descuento del 15% (tercera edad)");
            return precioBase * 0.85;
        }
        System.out.println("[DEBUG] Sin descuentos aplicables");
        return precioBase;
    }

    // F: Buscar entrada
    private static Entrada buscarEntrada(String asiento) {
        for (Entrada entrada : ventas) {
            if (entrada.asiento.equalsIgnoreCase(asiento)) {
                return entrada;
            }
        }
        return null;
    }

    // G: Buscar reserva
    private static Entrada buscarReserva(String asiento) {
        for (Entrada entrada : ventas) {
            if (entrada.asiento.equals(asiento) && entrada.estado.equals("Reservado")) {
                return entrada;
            }
        }
        return null;
    }

    // H: Liberar asiento
    private static void liberarAsiento(String asiento) {
        int fila = obtenerFila(asiento);
        int columna = obtenerColumna(asiento);
        
        if (fila != -1 && columna != -1) {
            if (asientos[fila][columna].equals(ASIENTO_RESERVADO)) {
                reservasTotales--;
            }
            asientos[fila][columna] = ASIENTO_DISPONIBLE;
            ventas.removeIf(e -> e.asiento.equals(asiento) && e.estado.equals("Reservado"));
        }
    }

    // I: Mostrar plano del teatro con precios 
    private static void mostrarPlanoAsientosConPrecios() {
        System.out.println("\n--- PLANO DE ASIENTOS CON PRECIOS ---");
        System.out.println("   1     2     3     4     5     6     7     8     9    10");
        
        for (int i = 0; i < asientos.length; i++) {
            char letraFila = (char) ('A' + i);
            String zona = "";
            double precio = 0;
            
            switch (letraFila) {
                case 'A' -> { zona = "VIP"; precio = PRECIO_VIP; }
                case 'B' -> { zona = "PLATEA"; precio = PRECIO_PLATEA; }
                case 'C' -> { zona = "GENERAL"; precio = PRECIO_GENERAL; }
            }
            
            System.out.printf("%s (%s $%.2f): ", letraFila, zona, precio);
            for (int j = 0; j < asientos[i].length; j++) {
                System.out.print(asientos[i][j] + " ");
            }
            System.out.println();
        }
        
        System.out.println("\nLeyenda:");
        System.out.println(ASIENTO_DISPONIBLE + " Disponible  " + 
                          ASIENTO_RESERVADO + " Reservado  " + 
                          ASIENTO_VENDIDO + " Vendido");
        System.out.printf("Precios: VIP $%.2f | Platea $%.2f | General $%.2f%n", 
                         PRECIO_VIP, PRECIO_PLATEA, PRECIO_GENERAL);
    }

    // J : Leer entero/double/positivo - evitar ingreso incorrecto de los datos
    private static int leerEntero() {
        while (!scanner.hasNextInt()) {
            System.out.println("Error: Debe ingresar un número entero.");
            scanner.next();
        }
        return scanner.nextInt();
    }

    private static double leerDouble() {
        while (!scanner.hasNextDouble()) {
            System.out.println("Error: Debe ingresar un número.");
            scanner.next();
        }
        return scanner.nextDouble();
    }
    
    private static int leerEnteroPositivo() {
        while (true) {
            int numero = leerEntero();
            if (numero >= 0) {
                return numero;
            }
            System.out.println("Error: La edad no puede ser negativa. Ingrese un valor válido:");
        }
    }

    //K: Validar y procesar asiento
    private static void validarYProcesarAsiento(String input, boolean esReserva, long numTransaccion) {
        System.out.println("[DEBUG] Validando asiento: " + input);
        
        String[] partes = input.split(" ");
        if (partes.length < 2) {
            System.out.println("Formato incorrecto. Debe ser: LetraNumero Zona (Ej: A1 VIP)");
            return;
        }
        
        String asiento = partes[0];
        String tipoZona = partes[1];
        double precioBase = obtenerPrecioZona(tipoZona);
        
        String mensajeError = !validarFormatoAsiento(asiento) ? "Formato de asiento incorrecto" :
                         !validarAsientoDisponible(asiento) ? "El asiento no está disponible" :
                         precioBase == 0 ? "Zona no válida" : null;
        
        if (mensajeError != null) {
            System.out.println("Error: " + mensajeError);
            return;
        }
        
        int fila = obtenerFila(asiento);
        int columna = obtenerColumna(asiento);
        
        System.out.printf("[DEBUG] Asiento: %s, Fila: %d, Columna: %d%n", asiento, fila, columna);
        
        if (fila == -1 || columna == -1) {
            System.out.println("Error: Asiento no válido.");
            return;
        }
        
        if (esReserva) {
            asientos[fila][columna] = ASIENTO_RESERVADO;
            reservasTotales++;
            ventas.add(new Entrada(asiento, "Reservado", precioBase, System.currentTimeMillis(), tipoZona, numTransaccion));
            System.out.println("Reserva exitosa: Asiento " + asiento);
        } else {
            asientos[fila][columna] = ASIENTO_VENDIDO;
            totalVendidas++;
            ingresosTotales += precioBase;
            ventas.add(new Entrada(asiento, "Comprado", precioBase, System.currentTimeMillis(), tipoZona, numTransaccion));
            System.out.println("Compra exitosa: Asiento " + asiento);
        }
        
        System.out.println("[DEBUG] Estado actual del asiento: " + asientos[fila][columna]);
    }

    // L: Mostrar disponibilidad de asiento (Disponible-Reservado-Vendido)
    private static void mostrarDisponibilidad() {
        System.out.println("\n--- DISPONIBILIDAD DE ASIENTOS ---");
        for (String[] fila : asientos) {
            for (String asiento : fila) {
                System.out.print(asiento + " ");
            }
            System.out.println();
        }
        System.out.println("Leyenda: " + 
                          ASIENTO_DISPONIBLE + " Disponible, " + 
                          ASIENTO_RESERVADO + " Reservado, " + 
                          ASIENTO_VENDIDO + " Vendido");
    }
    
    // M: Validar estado de asiento
    private static boolean validarEstado(String estado) {
    return estado != null && 
           (estado.equalsIgnoreCase("Reservado") || 
            estado.equalsIgnoreCase("Comprado") || 
            estado.equalsIgnoreCase("Cancelado"));
    }
    
    // N: Validar zona
    private static boolean validarZona(String zona) {
    if (zona == null) return false;
    String zonaUpper = zona.toUpperCase();
    return zonaUpper.equals("VIP") || zonaUpper.equals("PLATEA") || zonaUpper.equals("GENERAL");
    }
    
    // O: Validar imput asiento
    private static boolean validarInputAsiento(String input) {
    if (input == null || input.trim().isEmpty()) {
        System.out.println("[DEBUG] Input vacío");
        return false;
    }
    return true;
    }
    
    // P: Contador de asientos disponibles
    private static int contarAsientosDisponibles() {
        int count = 0;
        for (String[] fila : asientos) {
            for (String estado : fila) {
                if (estado.equals(ASIENTO_DISPONIBLE)) {
                    count++;
                }
            }
        }
        System.out.println("[DEBUG] Asientos disponibles: " + count); // Opcional: mensaje debug
        return count;
    }


    // Paso 5: Crear entradas 
    static class Entrada {
        String asiento;
        String estado;
        double precio;
        long timestamp;
        String zona;
        long numeroTransaccion;

        Entrada(String asiento, String estado, double precio, long timestamp, String zona, long numeroTransaccion) {
            if (asiento == null || estado == null || zona == null) {
                throw new IllegalArgumentException("Parámetros no pueden ser nulos");
            }
            if (precio < 0) {
                throw new IllegalArgumentException("Precio no puede ser negativo");
            }
            this.asiento = asiento;
            this.estado = estado;
            this.precio = precio;
            this.timestamp = timestamp;
            this.zona = zona;
            this.numeroTransaccion = numeroTransaccion;
        }

        @Override
        public String toString() {
            return String.format("Asiento: %s (%s), Estado: %s, Precio: $%.2f, N° Transacción: %d", 
               asiento, zona, estado, precio, numeroTransaccion);
        }
    }
}
















