/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exp2_s4_cristian_olivares;

/**
 *
 * @author Cristian Olivares Sandia
 * 
 */

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Exp2_S4_Cristian_Olivares {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Bienvenidos a la aplicacion del Teatro Moro\n");
            
            for (;;) {
                System.out.println("--- Menu Principal ---");
                System.out.println("1: Comprar entrada");
                System.out.println("2: Salir");
                System.out.print("Seleccione una opcion: ");
                
                String opcion = sc.nextLine();
                
                if (opcion.equals("1")) {
                    
                    String ubicacion = "";
                    while (true) {
                        System.out.println("\nPlano del Teatro:");
                        System.out.println("Fila A: [1] [2] [3] [4] [5] [6] [7] [8] [9] [10]");
                        System.out.println("Fila B: [1] [2] [3] [4] [5] [6] [7] [8] [9] [10]");
                        System.out.println("Fila C: [1] [2] [3] [4] [5] [6] [7] [8] [9] [10]");
                        System.out.print("Seleccione la zona (A, B, C): ");
                        ubicacion = sc.nextLine().toUpperCase();
                        
                        if (ubicacion.equals("A") || ubicacion.equals("B") || ubicacion.equals("C")) {
                            break;
                        } else {
                            System.out.println("Zona invalida. Intente nuevamente.");
                        }
                    }
                    
                    double precioBase = 0;
                    switch (ubicacion) {
                        case "A" -> precioBase = 20000;
                        case "B" -> precioBase = 15000;
                        case "C" -> precioBase = 10000;
                    }
                    
                    int asientoSeleccionado = 0;
                    while (true) {
                        System.out.print("Seleccione un asiento (1-10) para la Fila " + ubicacion + ": ");
                        try {
                            asientoSeleccionado = Integer.parseInt(sc.nextLine());
                            if (asientoSeleccionado >= 1 && asientoSeleccionado <= 10) {
                                break;
                            } else {
                                System.out.println("Número de asiento fuera de rango. Debe ser entre 1 y 10.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Entrada no valida. Intente nuevamente.");
                        }
                    }
                    
                    int edad = 0;
                    while (true) {
                        try {
                            System.out.print("Ingrese su edad: ");
                            edad = Integer.parseInt(sc.nextLine());
                            if (edad > 0 && edad < 120) {
                                break;
                            } else {
                                System.out.println("Edad fuera de rango. Intente nuevamente.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Entrada no valida. Intente nuevamente.");
                        }
                    }
                    
                    double descuento = 0;
                    String motivoDescuento = "ninguno";
                    
                    if (edad >= 65) {
                        descuento = 0.15;
                        motivoDescuento = "adulto mayor";
                    } else if (edad < 25) {
                        descuento = 0.10;
                        motivoDescuento = "estudiante";
                    }
                    
                    double precioFinal = precioBase - (precioBase * descuento);
                    
                    LocalDateTime ahora = LocalDateTime.now();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
                    String fechaHora = ahora.format(formatter);

                    System.out.println("\n--- Resumen de la compra ---");
                    System.out.println("Fecha y hora de la compra: " + fechaHora);
                    System.out.println("Ubicacion: Zona " + ubicacion);
                    System.out.println("Asiento seleccionado: " + asientoSeleccionado);
                    System.out.println("Precio base: $" + precioBase);
                    if (descuento > 0) {
                        System.out.println("Descuento aplicado: " + (int)(descuento * 100) + "% " + motivoDescuento);
                    } else {
                        System.out.println("Descuento aplicado: 0%");
                    }
                    System.out.println("Precio final a pagar: $" + precioFinal);
                    
                    String respuesta;
                    while (true){
                        System.out.print("\n ¿Desea realizar otra compra? (S/N): ");
                        respuesta = sc.nextLine().toUpperCase();
                        if (respuesta.equals("S") || respuesta.equals("N")){
                            break;
                        } else {
                            System.out.println("Respuesta no valida. Ingrese S o N");
                        }
                    }
                    
                    if (respuesta.equals("N")){
                        System.out.println("Gracias por usar la aplicacion.");
                        break;
                    }
                    
                } else if (opcion.equals("2")) {
                    System.out.println("Gracias por usar la aplicacion.");
                    break;
                } else {
                    System.out.println("Opcion no valida. Intente nuevamente.\n");
                }
            }
        }
    }
}
