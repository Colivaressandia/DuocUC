/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exp2_s4_cristian_olivares;

/**
 *
 * @author Cristian Olivares Sandia
 * 
 */

import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Exp2_S4_Cristian_Olivares {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Bienvenidos a la aplicacion del Teatro Moro\n");
            
            // Paso 1: Menú principal con ciclo for
            for (;;) {
                System.out.println("--- Menu Principal ---");
                System.out.println("1: Comprar entrada");
                System.out.println("2: Salir");
                System.out.print("Seleccione una opcion: ");
                
                String opcion = sc.nextLine();
                
                if (opcion.equals("1")) {
                    
                    // Paso 2: Mostrar plano del teatro y solicitar ubicacion
                    String ubicacion = "";
                    while (true) {
                        System.out.println("\nPlano del Teatro: [Zona A] [Zona B] [Zona C]");
                        System.out.print("Seleccione la zona (A, B, C): ");
                        ubicacion = sc.nextLine().toUpperCase();
                        
                        if (ubicacion.equals("A") || ubicacion.equals("B") || ubicacion.equals("C")) {
                            break;
                        } else {
                            System.out.println("Zona invalida. Intente nuevamente.");
                        }
                    }
                    
                    // Paso 3: Asignar precio base segun zona
                    double precioBase = 0;
                    switch (ubicacion) {
                        case "A" -> precioBase = 20000;
                        case "B" -> precioBase = 15000;
                        case "C" -> precioBase = 10000;
                    }
                    
                    // Paso 4: Solicitar edad con validacion
                    int edad = 0;
                    while (true) {
                        try {
                            System.out.print("Ingrese su edad: ");
                            edad = Integer.parseInt(sc.nextLine());
                            if (edad > 0 && edad < 120) {
                                break;
                            } else {
                                System.out.println("Edad fuera de rango. Intente nuevamente.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Entrada no valida. Intente nuevamente.");
                        }
                    }
                    
                    // Paso 5: Preguntar si es estudiante
                    System.out.print("¿Es estudiante? (S/N): ");
                    String estudiante = sc.nextLine().toUpperCase();
                    
                    while (!estudiante.equals("S") && !estudiante.equals("N")) {
                        System.out.print("Respuesta inválida. ¿Es estudiante? (S/N): ");
                        estudiante = sc.nextLine().toUpperCase();}
                    
                    // Paso 2: Calcular precio final usando ciclo while
                    double descuento = 0;
                    boolean calculado = false;
                    while (!calculado) {
                        if (edad >= 65) {
                            descuento = 0.15;
                            calculado = true;
                        } else if (estudiante.equals("S")) {
                            descuento = 0.10;
                            calculado = true;
                        } else {
                            descuento = 0;
                            calculado = true;
                        }
                    }
                    
                    double precioFinal = precioBase - (precioBase * descuento);
                    LocalDateTime ahora = LocalDateTime.now();
                    DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
                    String fechaHora = ahora.format(formato);
                    
                    // Paso 6: Mostrar resumen
                    System.out.println("\n--- Resumen de la compra ---");
                    System.out.println("Fecha y hora de la compra: " + fechaHora);
                    System.out.println("Ubicacion: Zona " + ubicacion);
                    System.out.println("Precio base: $" + precioBase);
                    System.out.println("Descuento aplicado: " + (int)(descuento * 100) + "%");
                    System.out.println("Precio final a pagar: $" + precioFinal);
                    
                    // Paso 7: Preguntar si desea continuar
                    String respuesta;
                    while (true){
                    System.out.print("\n ¿Desea realizar otra compra? (S/N): ");
                    respuesta = sc.nextLine().toUpperCase();
                    if (respuesta.equals("S")|| respuesta.equals("N")){
                        break;
                    }else{
                            System.out.println("Respuesta no valida. Ingrese S o N");
                            }
                }
                
                if (respuesta.equals ("N")){
                    System.out.println("Gracias por usar la aplicacion");
                    break;
                }
                    
                    //Paso 8: Mensaje de cierre
                } else if (opcion.equals("2")) {
                    System.out.println("Gracias por usar la aplicacion.");
                    break;
                } else {
                    System.out.println("Opcion no valida. Intente nuevamente.\n");
                }
            }
        }
    }
} 
     
    