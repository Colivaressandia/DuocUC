/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepcion;

/**
 * Excepción personalizada que se lanza cuando se intenta vender un cómic sin stock disponible.
 */
public class ComicSinStockException extends Exception {
    public ComicSinStockException(String mensaje) {
        super(mensaje);
    }
}