/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepcion;

/**
 * Excepción personalizada que se lanza cuando no se encuentra un cómic en el catálogo.
 */
public class ComicNoEncontradoException extends Exception {
    public ComicNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}