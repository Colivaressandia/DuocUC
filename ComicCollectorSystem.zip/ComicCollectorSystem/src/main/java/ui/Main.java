/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

import servicio.ComicStore;
import excepcion.ComicNoEncontradoException;
import excepcion.ComicSinStockException;
import modelo.Usuario;
import modelo.Comic;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;


/**
 * Clase principal que ejecuta la interfaz de usuario por consola para el sistema Comic Collector.
 * Permite la interacción con el usuario y el acceso a las funcionalidades del sistema.
 */

public class Main {

    public static String normalizarRut(String rut) {
        if (rut == null) return "";
        return rut.replace(".", "").replace("-", "").replace(" ", "").toUpperCase();
    }

    public static boolean validarRut(String rut) {
        return rut.matches("^\\d{1,2}\\.\\d{3}\\.\\d{3}-[\\dkK]$")
                || rut.matches("^\\d{7,8}-[\\dkK]$")
                || rut.matches("^\\d{8,9}$");
    }

    public static boolean validarNombre(String nombre) {
        return nombre != null && nombre.trim().matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,}$") && !nombre.trim().isEmpty();
    }

    public static boolean validarCorreo(String correo) {
        return correo != null && correo.matches("^[^@\\s]+@[^@\\s]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean validarTelefono(String telefono) {
        return telefono != null && telefono.matches("^\\d{9}$");
    }

    public static void registrarUsuario(ComicStore store, Scanner scanner, String rutExistente) {
        String rut;
        if (rutExistente != null) {
            rut = rutExistente;
            System.out.println("Registrando nuevo usuario con RUT: " + rut);
        } else {
            while (true) {
                System.out.print("Ingrese RUT (puede ser 12.345.678-9, 12345678-9 o 123456789): ");
                rut = scanner.nextLine();
                if (!validarRut(rut)) {
                    System.out.println("RUT inválido. Intente nuevamente.");
                    continue;
                }
                rut = normalizarRut(rut);
                if (store.getUsuarios().containsKey(rut)) {
                    System.out.println("Ese RUT ya está registrado.");
                    return;
                }
                break;
            }
        }
        rut = normalizarRut(rut);

        String nombre;
        while (true) {
            System.out.print("Ingrese su primer nombre: ");
            nombre = scanner.nextLine();
            if (!validarNombre(nombre)) {
                System.out.println("Nombre inválido. Solo letras y espacios. Intente nuevamente.");
            } else {
                break;
            }
        }

        String apellido;
        while (true) {
            System.out.print("Ingrese su primer apellido: ");
            apellido = scanner.nextLine();
            if (!validarNombre(apellido)) {
                System.out.println("Apellido inválido. Solo letras y espacios. Intente nuevamente.");
            } else {
                break;
            }
        }

        String telefono;
        while (true) {
            System.out.print("Ingrese su teléfono (9 dígitos): ");
            telefono = scanner.nextLine();
            if (!validarTelefono(telefono)) {
                System.out.println("Teléfono inválido. Debe tener exactamente 9 números. Intente nuevamente.");
            } else {
                break;
            }
        }

        String correo;
        while (true) {
            System.out.print("Ingrese su correo electrónico: ");
            correo = scanner.nextLine();
            if (!validarCorreo(correo)) {
                System.out.println("Correo inválido. Debe tener formato usuario@dominio.com/.cl/.org/etc. Intente nuevamente.");
            } else {
                break;
            }
        }

        String nombreCompleto = nombre.trim() + " " + apellido.trim();
        Usuario usuario = new Usuario(rut, nombreCompleto, telefono, correo);
        store.agregarUsuario(usuario);
        System.out.println("Usuario registrado exitosamente.");
    }

    public static void registrarUsuario(ComicStore store, Scanner scanner) {
        registrarUsuario(store, scanner, null);
    }

    public static void cargarComicsEjemplo(ComicStore store) {
        store.agregarComic(new Comic("DC001", "Batman: Year One", "Frank Miller", 12000, 5, "DC/Batman"));
        store.agregarComic(new Comic("DC002", "Batman: The Killing Joke", "Alan Moore", 15000, 3, "DC/Batman"));
        store.agregarComic(new Comic("DC003", "Superman: Red Son", "Mark Millar", 13000, 4, "DC/Superman"));
        store.agregarComic(new Comic("MAR001", "X-Men: Days of Future Past", "Chris Claremont", 14000, 3, "Marvel/X-Men"));
        store.agregarComic(new Comic("MAR002", "Spider-Man: Blue", "Jeph Loeb", 11500, 5, "Marvel/Spider-Man"));
        store.agregarComic(new Comic("MAR003", "Iron Man: Extremis", "Warren Ellis", 11000, 2, "Marvel/Iron Man"));
        store.agregarComic(new Comic("MAR004", "Daredevil: Born Again", "Frank Miller", 12500, 2, "Marvel/Daredevil"));
        store.agregarComic(new Comic("MAR005", "Infinity Gauntlet", "Jim Starlin", 17000, 1, "Marvel/Otros"));
        store.agregarComic(new Comic("DC004", "Watchmen", "Alan Moore", 18000, 2, "DC/Otros"));
        store.agregarComic(new Comic("DC005", "Justice League: Tower of Babel", "Mark Waid", 13500, 2, "DC/Justice League"));
        store.agregarComic(new Comic("DC006", "All-Star Superman", "Grant Morrison", 15500, 3, "DC/Superman"));
        // Puedes agregar más cómics aquí...
    }

    public static void main(String[] args) {
        ComicStore store = new ComicStore();
        Scanner scanner = new Scanner(System.in);

        System.out.println("*************************************");
        System.out.println("*  Bienvenido(a) a Comic Collector  *");
        System.out.println("*************************************");
        System.out.println("¡Compra y gestiona tus cómics favoritos!\n");

        // Intenta cargar desde archivo, si no hay, carga ejemplos
        try {
            store.cargarComicsDesdeArchivo("catalogo_comics.csv");
            System.out.println("Catálogo cargado desde archivo.");
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo catalogo_comics.csv, se cargarán cómics de ejemplo.");
            cargarComicsEjemplo(store);
        }

        boolean salir = false;
        while (!salir) {
            System.out.println("\n--- Comic Collector ---");
            System.out.println("1. Registrar usuario");
            System.out.println("2. Catálogo por categorías");
            System.out.println("3. Catálogo completo");
            System.out.println("4. Buscar cómic");
            System.out.println("5. Comprar cómic");
            System.out.println("6. Guardar catálogo en archivo");
            System.out.println("7. Cargar catálogo desde archivo");
            System.out.println("8. Mostrar cómics únicos (HashSet)");
            System.out.println("9. Mostrar catálogo ordenado (TreeSet)");
            System.out.println("10. Mostrar usuarios únicos (HashSet)");
            System.out.println("11. Mostrar usuarios ordenados (TreeSet)");
            System.out.println("12. Reponer stock de cómic");
            System.out.println("13. Salir");

            try {
                System.out.print("Seleccione opción: ");
                int opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1 -> registrarUsuario(store, scanner);
                    case 2 -> store.mostrarComicsPorCategoria(); // Catálogo agrupado
                    case 3 -> store.mostrarComics(); // Catálogo completo
                    case 4 -> {
                        System.out.print("Ingrese título o autor a buscar: ");
                        String busqueda = scanner.nextLine();
                        List<Comic> resultados = store.buscarComics(busqueda);

                        if (resultados.isEmpty()) {
                            System.out.println("No se encontraron cómics.");
                        } else {
                            System.out.println("Resultados:");
                            int i = 1;
                            for (Comic c : resultados) {
                                System.out.println(i + ". " + c);
                                i++;
                            }
                            System.out.print("¿Desea comprar uno de estos cómics? (s/n): ");
                            String opcionCompra = scanner.nextLine();
                            if (opcionCompra.equalsIgnoreCase("s")) {
                                System.out.print("Ingrese el número del cómic que desea comprar: ");
                                int numComic = scanner.nextInt();
                                scanner.nextLine();
                                if (numComic < 1 || numComic > resultados.size()) {
                                    System.out.println("[ERROR] Número inválido.");
                                } else {
                                    Comic comicSeleccionado = resultados.get(numComic - 1);
                                    System.out.print("Ingrese RUT usuario: ");
                                    String rut = scanner.nextLine();
                                    rut = normalizarRut(rut);
                                    if (!store.getUsuarios().containsKey(rut)) {
                                        System.out.println("El RUT no está registrado. Por favor, complete el registro:");
                                        registrarUsuario(store, scanner, rut);
                                    }
                                    try {
                                        store.venderComicPorId(comicSeleccionado.getCodigo(), rut);
                                    } catch (ComicNoEncontradoException | ComicSinStockException e) {
                                        System.out.println("[ERROR] " + e.getMessage());
                                    }
                                }
                            }
                        }
                    }
                    case 5 -> {
                        List<Comic> catalogo = store.getComics();
                        if (catalogo.isEmpty()) {
                            System.out.println("No hay cómics en la tienda.");
                        } else {
                            System.out.println("Catálogo:");
                            int i = 1;
                            for (Comic c : catalogo) {
                                System.out.println(i + ". " + c);
                                i++;
                            }
                            System.out.print("Ingrese el número del cómic que desea comprar: ");
                            int numComic = scanner.nextInt();
                            scanner.nextLine();
                            if (numComic < 1 || numComic > catalogo.size()) {
                                System.out.println("[ERROR] Número inválido.");
                            } else {
                                Comic comicSeleccionado = catalogo.get(numComic - 1);
                                System.out.print("Ingrese RUT usuario: ");
                                String rut = scanner.nextLine();
                                rut = normalizarRut(rut);

                                if (!store.getUsuarios().containsKey(rut)) {
                                    System.out.println("El RUT no está registrado. Por favor, complete el registro:");
                                    registrarUsuario(store, scanner, rut);
                                }
                                try {
                                    store.venderComicPorId(comicSeleccionado.getCodigo(), rut);
                                } catch (ComicNoEncontradoException | ComicSinStockException e) {
                                    System.out.println("[ERROR] " + e.getMessage());
                                }
                            }
                        }
                    }
                    case 6 -> {
                        try {
                            store.guardarInforme("catalogo_comics.csv");
                            System.out.println("Catálogo guardado exitosamente en catalogo_comics.csv");
                        } catch (IOException e) {
                            System.out.println("Error al guardar el catálogo: " + e.getMessage());
                        }
                    }
                    case 7 -> {
                        try {
                            store.cargarComicsDesdeArchivo("catalogo_comics.csv");
                            System.out.println("Catálogo cargado exitosamente desde catalogo_comics.csv");
                        } catch (IOException e) {
                            System.out.println("Error al cargar el catálogo: " + e.getMessage());
                        }
                    }
                    case 8 -> {
                        System.out.println("Cómics únicos (sin repetir código):");
                        if (store.getComicsUnicos().isEmpty()) {
                            System.out.println("No hay cómics en la tienda.");
                        } else {
                            for (Comic comic : store.getComicsUnicos()) {
                                System.out.println(comic);
                            }
                        }
                    }
                    case 9 -> {
                        System.out.println("Catálogo ordenado (por título y código):");
                        if (store.getCatalogoOrdenado().isEmpty()) {
                            System.out.println("No hay cómics en la tienda.");
                        } else {
                            for (Comic comic : store.getCatalogoOrdenado()) {
                                System.out.println(comic);
                            }
                        }
                    }
                    case 10 -> {
                        System.out.println("Usuarios únicos (sin repetir RUT):");
                        if (store.getUsuariosUnicos().isEmpty()) {
                            System.out.println("No hay usuarios registrados.");
                        } else {
                            for (Usuario usuario : store.getUsuariosUnicos()) {
                                System.out.println(usuario);
                            }
                        }
                    }
                    case 11 -> {
                        System.out.println("Usuarios ordenados (por nombre completo):");
                        if (store.getUsuariosOrdenados().isEmpty()) {
                            System.out.println("No hay usuarios registrados.");
                        } else {
                            for (Usuario usuario : store.getUsuariosOrdenados()) {
                                System.out.println(usuario);
                            }
                        }
                    }
                    case 12 -> {
                        List<Comic> catalogo = store.getComics();
                        if (catalogo.isEmpty()) {
                            System.out.println("No hay cómics en la tienda.");
                        } else {
                            System.out.println("Catálogo:");
                            int i = 1;
                            for (Comic c : catalogo) {
                                System.out.println(i + ". " + c);
                                i++;
                            }
                            System.out.print("Ingrese el número del cómic al que desea reponer stock: ");
                            int numComic = scanner.nextInt();
                            scanner.nextLine();
                            if (numComic < 1 || numComic > catalogo.size()) {
                                System.out.println("[ERROR] Número inválido.");
                            } else {
                                Comic comicSeleccionado = catalogo.get(numComic - 1);
                                System.out.print("Ingrese la cantidad a reponer: ");
                                int cantidad = scanner.nextInt();
                                scanner.nextLine();
                                try {
                                    store.reponerComicPorId(comicSeleccionado.getCodigo(), cantidad);
                                } catch (ComicNoEncontradoException e) {
                                    System.out.println("[ERROR] " + e.getMessage());
                                }
                            }
                        }
                    }
                    case 13 -> salir = true;
                    default -> System.out.println("Opción inválida");
                }

            } catch (InputMismatchException e) {
                System.out.println("Debe ingresar un número de opción válido.");
                scanner.nextLine();
            }
        }

        scanner.close();
    }
}