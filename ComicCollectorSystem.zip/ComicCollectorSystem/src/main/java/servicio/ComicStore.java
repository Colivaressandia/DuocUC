/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import modelo.Comic;
import modelo.Usuario;
import excepcion.ComicNoEncontradoException;
import excepcion.ComicSinStockException;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Clase principal que gestiona el catálogo de cómics y los usuarios en Comic Collector.
 * Permite agregar, buscar, vender y reponer cómics, así como registrar usuarios y manejar la persistencia de datos.
 */

public class ComicStore {
    private List<Comic> comics;
    private Map<String, Usuario> usuarios;

    
     /**
     * Crea una nueva tienda de cómics con catálogos y usuarios vacíos.
     */
    public ComicStore() {
        comics = new ArrayList<>();
        usuarios = new HashMap<>();
    }

    // ==== USUARIOS ====
    public Map<String, Usuario> getUsuarios() {
        return usuarios;
    }

    public void agregarUsuario(Usuario usuario) {
        usuarios.put(usuario.getRut(), usuario);
    }

    public Set<Usuario> getUsuariosUnicos() {
        return new HashSet<>(usuarios.values());
    }

    public Set<Usuario> getUsuariosOrdenados() {
        return new TreeSet<>(usuarios.values());
    }

    // ==== COMICS ====
     /**
     * Agrega un cómic al catálogo.
     * @param comic Cómic a agregar.
     */
    public void agregarComic(Comic comic) {
        comics.add(comic);
    }
    
     /**
     * Obtiene la lista completa del catálogo de cómics.
     * @return Lista de cómics.
     */
    public List<Comic> getComics() {
        return comics;
    }

    public Comic buscarComicPorCodigo(String codigo) {
        for (Comic c : comics) {
            if (c.getCodigo().equalsIgnoreCase(codigo)) {
                return c;
            }
        }
        return null;
    }

    public boolean eliminarComicPorCodigo(String codigo) {
        Iterator<Comic> it = comics.iterator();
        while (it.hasNext()) {
            Comic c = it.next();
            if (c.getCodigo().equalsIgnoreCase(codigo)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    public void mostrarComics() {
        if (comics.isEmpty()) {
            System.out.println("No hay cómics en el catálogo.");
        } else {
            for (Comic c : comics) {
                System.out.println(c);
            }
        }
    }

     /**
     * Muestra los cómics agrupados por categoría.
     */
    public void mostrarComicsPorCategoria() {
        if (comics.isEmpty()) {
            System.out.println("No hay cómics en el catálogo.");
            return;
        }
        Map<String, List<Comic>> catMap = new TreeMap<>();
        for (Comic c : comics) {
            catMap.computeIfAbsent(c.getCategoria(), k -> new ArrayList<>()).add(c);
        }
        for (Map.Entry<String, List<Comic>> entry : catMap.entrySet()) {
            System.out.println("Categoría: " + entry.getKey());
            for (Comic c : entry.getValue()) {
                System.out.println("   " + c);
            }
            System.out.println();
        }
    }

     /**
     * Busca cómics cuyo título o autor contenga la cadena dada (ignorando mayúsculas).
     * @param busqueda Cadena de búsqueda.
     * @return Lista de cómics que coinciden.
     */
    public List<Comic> buscarComics(String termino) {
        List<Comic> resultado = new ArrayList<>();
        String term = termino.toLowerCase();
        for (Comic c : comics) {
            if (c.getTitulo().toLowerCase().contains(term) || c.getAutor().toLowerCase().contains(term)) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    public Set<Comic> getComicsUnicos() {
        return new HashSet<>(comics);
    }

    public Set<Comic> getCatalogoOrdenado() {
        return new TreeSet<>(comics);
    }

    /**
     * Vende un cómic a un usuario, disminuyendo el stock.
     * @param codigo Código del cómic a vender.
     * @param rutUsuario RUT del usuario que realiza la compra.
     * @throws ComicNoEncontradoException Si el cómic no existe.
     * @throws ComicSinStockException Si no hay stock disponible.
     */
    public void venderComicPorId(String id, String rutUsuario) throws ComicNoEncontradoException, ComicSinStockException {
        Comic comic = null;
        for (Comic c : comics) {
            if (c.getCodigo().equalsIgnoreCase(id)) {
                comic = c;
                break;
            }
        }
        if (comic == null) throw new ComicNoEncontradoException("Cómic no encontrado.");
        if (comic.getStock() <= 0) throw new ComicSinStockException("Sin stock.");
        comic.setStock(comic.getStock() - 1);
        System.out.println("¡Compra realizada con éxito!");
    }
    
    
    /**
     * Repone el stock de un cómic.
     * @param codigo Código del cómic a reponer.
     * @param cantidad Cantidad a reponer.
     * @throws ComicNoEncontradoException Si el cómic no existe.
     */
    public void reponerComicPorId(String id, int cantidad) throws ComicNoEncontradoException {
        Comic comic = null;
        for (Comic c : comics) {
            if (c.getCodigo().equalsIgnoreCase(id)) {
                comic = c;
                break;
            }
        }
        if (comic == null) throw new ComicNoEncontradoException("Cómic no encontrado.");
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad inválida.");
        comic.setStock(comic.getStock() + cantidad);
        System.out.println("Stock repuesto con éxito.");
    }

     /**
     * Carga cómics desde un archivo CSV.
     * @param archivo Nombre del archivo.
     * @throws IOException Si ocurre un error de entrada/salida.
     */

    public void cargarComicsDesdeArchivo(String archivo) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(archivo));
        String linea;
        int numLinea = 0;
        Pattern pattern = Pattern.compile("\"([^\"]*)\"|([^,]+)");
        while ((linea = br.readLine()) != null) {
            numLinea++;
            if (numLinea == 1 && linea.toLowerCase().startsWith("id,")) continue;
            if (linea.trim().isEmpty()) continue;

            List<String> campos = new ArrayList<>();
            Matcher matcher = pattern.matcher(linea);
            while (matcher.find()) {
                String campo = matcher.group(1);
                if (campo != null) {
                    campos.add(campo);
                } else {
                    campo = matcher.group(2);
                    if (campo != null)
                        campos.add(campo);
                }
            }

            try {
                if (campos.size() < 7) {
                    System.err.println("Línea " + numLinea + " inválida: " + linea);
                    continue;
                }
                String codigo = campos.get(1).trim();
                String titulo = campos.get(2).trim();
                String autor = campos.get(3).trim();
                double precio = Double.parseDouble(campos.get(4).trim());
                int stock = Integer.parseInt(campos.get(5).trim());
                String categoria = campos.get(6).trim();
                Comic comic = new Comic(codigo, titulo, autor, precio, stock, categoria);
                this.agregarComic(comic);
            } catch (Exception e) {
                System.err.println("Error en línea " + numLinea + ": " + linea);
                System.err.println("Detalle: " + e.getMessage());
            }
        }
        br.close();
    }

    public void guardarComicsEnArchivo(String archivo) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
        bw.write("ID,Código,Título,Autor,Precio,Stock,Categoría,ÚltimoComprador");
        bw.newLine();
        int id = 1;
        for (Comic c : comics) {
            String titulo = c.getTitulo();
            if (titulo.contains(",")) {
                titulo = "\"" + titulo + "\"";
            }
            String linea = id + "," + c.getCodigo() + "," + titulo + "," + c.getAutor() + "," +
                    c.getPrecio() + "," + c.getStock() + "," + c.getCategoria() + ",";
            bw.write(linea);
            bw.newLine();
            id++;
        }
        bw.close();
    }

    // Si tu main llama a store.guardarInforme(), puedes hacer simplemente:
    public void guardarInforme(String archivo) throws IOException {
        guardarComicsEnArchivo(archivo);
    }
}