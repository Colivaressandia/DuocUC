/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Objects;

/**
 * Representa un usuario registrado en el sistema Comic Collector.
 * Almacena el RUT, nombre completo, teléfono y correo electrónico del usuario.
 */
public class Usuario implements Comparable<Usuario> {
    /**
     * RUT único del usuario.
     */
    private String rut;
     /**
     * Nombre completo del usuario.
     */
    private String nombreCompleto;
     /**
     * Teléfono del usuario.
     */
    private String telefono;
     /**
     * Correo electrónico del usuario.
     */
    private String correo;
    
     /**
     * Crea un nuevo usuario con los parámetros dados.
     * @param rut RUT del usuario.
     * @param nombreCompleto Nombre completo.
     * @param telefono Teléfono.
     * @param correo Correo electrónico.
     */
    public Usuario(String rut, String nombreCompleto, String telefono, String correo) {
        this.rut = rut;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.correo = correo;
    }
    
     /**
     * Obtiene el RUT del usuario.
     * @return RUT.
     */
    public String getRut() { return rut; }
     /**
     * Obtiene el nombre completo del usuario.
     * @return Nombre completo.
     */
    public String getNombreCompleto() { return nombreCompleto; }
     /**
     * Obtiene el teléfono del usuario.
     * @return Teléfono.
     */
    public String getTelefono() { return telefono; }
     /**
     * Obtiene el correo del usuario.
     * @return Correo electrónico.
     */
    public String getCorreo() { return correo; }

    @Override
    public String toString() {
        return rut + " - " + nombreCompleto + " - " + telefono + " - " + correo;
    }

    // Para HashSet y HashMap: considera iguales los usuarios con mismo RUT
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        Usuario usuario = (Usuario) o;
        return rut.equalsIgnoreCase(usuario.rut);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rut.toLowerCase());
    }

     /**
     * Compara dos usuarios por nombre completo.
     * @param otro El otro usuario a comparar.
     * @return Valor negativo, cero o positivo según el orden.
     */
    @Override
    public int compareTo(Usuario otro) {
        int comp = this.nombreCompleto.compareToIgnoreCase(otro.nombreCompleto);
        if (comp == 0) {
            comp = this.rut.compareToIgnoreCase(otro.rut);
        }
        return comp;
    }
}