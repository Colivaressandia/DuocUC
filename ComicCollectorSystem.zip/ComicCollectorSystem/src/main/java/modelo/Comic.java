/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Representa un cómic dentro del sistema Comic Collector.
 * Almacena información relevante como código, título, autor, precio, stock y categoría.
 * Implementa Comparable para permitir el ordenamiento por título y código.
 */


public class Comic implements Comparable<Comic> {
    /**
     * Código único del cómic.
     */
    private String codigo;
     /**
     * Título del cómic.
     */
    private String titulo;
     /**
     * Autor del cómic.
     */
    private String autor;
     /**
     * Precio del cómic.
     */
    private double precio;
     /**
     * Stock disponible del cómic.
     */
    private int stock;
     /**
     * Categoría a la que pertenece el cómic.
     */
    private String categoria;

    // Constructor
     /**
     * Crea un nuevo objeto Comic con los valores dados.
     *
     * @param codigo    Código único del cómic.
     * @param titulo    Título del cómic.
     * @param autor     Autor del cómic.
     * @param precio    Precio del cómic.
     * @param stock     Stock disponible.
     * @param categoria Categoría del cómic.
     */
    public Comic(String codigo, String titulo, String autor, double precio, int stock, String categoria) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.autor = autor;
        this.precio = precio;
        this.stock = stock;
        this.categoria = categoria;
    }

    // Getters
     /**
     * Obtiene el código del cómic.
     * @return Código del cómic.
     */
    public String getCodigo() {
        return codigo;
    }
    
     /**
     * Obtiene el título del cómic.
     * @return Título del cómic.
     */
    public String getTitulo() {
        return titulo;
    }
    
    /**
     * Obtiene el autor del cómic.
     * @return Autor del cómic.
     */

    public String getAutor() {
        return autor;
    }
    
    /**
     * Obtiene el precio del cómic.
     * @return Precio del cómic.
     */
    public double getPrecio() {
        return precio;
    }
    
    /**
     * Obtiene el stock disponible.
     * @return Stock disponible.
     */
    public int getStock() {
        return stock;
    }
    
    /**
     * Obtiene la categoría del cómic.
     * @return Categoría del cómic.
     */
    public String getCategoria() {
        return categoria;
    }

    // Setters
    /**
     * Establece el stock disponible.
     * @param stock Nuevo valor de stock.
     */
    public void setStock(int stock) {
        this.stock = stock;
    }


    /**
     * Compara dos cómics por título y luego por código.
     * @param otroComic El otro cómic a comparar.
     * @return Un valor negativo, cero o positivo según el orden.
     */
    @Override
    public int compareTo(Comic other) {
        int compTitulo = this.titulo.compareToIgnoreCase(other.titulo);
        if (compTitulo != 0) return compTitulo;
        return this.codigo.compareToIgnoreCase(other.codigo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Comic)) return false;
        Comic other = (Comic) obj;
        return codigo != null && codigo.equalsIgnoreCase(other.codigo);
    }

    @Override
    public int hashCode() {
        return codigo == null ? 0 : codigo.toLowerCase().hashCode();
    }
    
    /**
     * Devuelve una representación en texto del cómic.
     * @return Cadena descriptiva del cómic.
     */
    @Override
    public String toString() {
        return "Código: " + codigo +
               ", Título: " + titulo +
               ", Autor: " + autor +
               ", Precio: " + precio +
               ", Stock: " + stock +
               ", Categoría: " + categoria;
    }
}